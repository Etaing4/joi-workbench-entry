#!/usr/bin/env python3
"""calculator.py — fully offline unit-economics calculator (F track).

Reads exactly one JSON object from stdin with exactly ten finite nonnegative numeric
keys (no booleans) and prints exactly one JSON object with seven keys. Invalid input
exits nonzero with an explanation on stderr. No network, no clock, no secrets.
"""
import json
import math
import sys

KEYS = [
    'price_usd', 'leads', 'conversion_rate', 'refund_rate', 'fee_rate',
    'variable_cost_per_order_usd', 'labor_minutes_per_order', 'hourly_labor_usd',
    'fixed_cost_usd', 'acquisition_cost_usd',
]
RATE_KEYS = ('conversion_rate', 'refund_rate', 'fee_rate')


def fail(message):
    sys.stderr.write('invalid input: %s\n' % message)
    raise SystemExit(2)


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def compute(v):
    leads = v['leads']
    conv = v['conversion_rate']
    refund = v['refund_rate']
    fee = v['fee_rate']
    var_cost = v['variable_cost_per_order_usd']
    minutes = v['labor_minutes_per_order']
    hour_rate = v['hourly_labor_usd']
    fixed = v['fixed_cost_usd']
    cac_total = v['acquisition_cost_usd']

    expected_orders = leads * conv
    unit_net = v['price_usd'] * (1 - refund) * (1 - fee)
    unit_fulfillment = var_cost + (minutes / 60) * hour_rate
    unit_contribution = unit_net - unit_fulfillment
    net_revenue = expected_orders * unit_net
    fulfillment_cost = expected_orders * unit_fulfillment
    profit = net_revenue - fulfillment_cost - fixed - cac_total
    break_even = (math.ceil((fixed + cac_total) / unit_contribution)
                  if unit_contribution > 0 else None)
    cac = cac_total / expected_orders if expected_orders > 0 else None
    return {
        'expected_orders': expected_orders,
        'net_revenue_usd': net_revenue,
        'fulfillment_cost_usd': fulfillment_cost,
        'profit_usd': profit,
        'contribution_per_order_usd': unit_contribution,
        'break_even_orders': break_even,
        'cac_usd': cac,
    }


def main():
    try:
        raw = sys.stdin.read()
    except OSError as exc:
        fail('cannot read stdin: %s' % exc)
    try:
        obj = json.loads(raw)
    except ValueError as exc:
        fail('body must be one JSON object (%s)' % exc)
    if not isinstance(obj, dict):
        fail('body must be a JSON object')
    missing = [k for k in KEYS if k not in obj]
    extra = [k for k in obj if k not in KEYS]
    if missing:
        fail('missing key(s): %s' % ','.join(missing))
    if extra:
        fail('unexpected key(s): %s' % ','.join(sorted(extra)))
    for k in KEYS:
        if not _num(obj[k]):
            fail('%s must be a finite non-boolean number' % k)
        if obj[k] < 0:
            fail('%s must be nonnegative' % k)
    for k in RATE_KEYS:
        if obj[k] > 1:
            fail('%s must be a fraction in [0,1]' % k)
    print(json.dumps(compute(obj), allow_nan=False))


if __name__ == '__main__':
    main()
