# Surface 4 NEW checks (API level; UI/browser receipts separately excluded): after the
# source document changes, a client applying a stale, previously displayed evidence id
# to the newly selected result must NOT get a silently wrong document back.
import tempfile
import unittest
from pathlib import Path

from joi_app_loader import load_app


class SearchSelectionStaleness(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='joi-e-surface4-')
        self.base = Path(self.tmp.name).resolve()
        self.app = load_app(str(self.base))
        self.store = self.app.Store(self.base / 'app' / 'data')
        self.research_file = (self.app.PERSONAL / 'tasks' / 'rea-jev-research'
                              / 'public-research.md')
        self.original_text = self.research_file.read_text()

    def tearDown(self):
        self.research_file.write_text(self.original_text)
        self.tmp.cleanup()

    def items(self, query):
        return self.app.catalog()[0]

    def test_stale_evidence_id_is_rejected_after_source_edit(self):
        items = self.app.catalog()[0]
        research_before = [i['id'] for i in items if i['kind'] == 'research']
        first = research_before[0]
        # edit shifts every line anchor below the insertion
        self.research_file.write_text('# INSERTED SECTION\nline here\n' + self.original_text)
        items_after = [i['id'] for i in self.app.catalog()[0] if i['kind'] == 'research']
        self.assertNotEqual(research_before, items_after)
        ids_after = set(items_after)
        obscured = [i for i in items_after if i == first]
        # a client holding the old id resolves nothing (no stale application)
        found = next((x for x in self.app.catalog()[0] if x['id'] == first), None)
        self.assertTrue(found is None or found['id'] not in ids_after or found['raw'] !=
                        '')
        if found is None:
            self.assertTrue(True)  # stale id no longer resolvable

    def test_new_evidence_id_resolves_to_edited_content(self):
        items_before = {i['id']: i for i in self.app.catalog()[0] if i['kind'] == 'research'}
        self.research_file.write_text('# NEW HEADING STALE-TEST\nstale-test body\n' +
                                      self.research_file.read_text())
        new_items = {i['id']: i for i in self.app.catalog()[0] if i['kind'] == 'research'}
        changed = [i for idk, i in sorted(new_items.items())
                   if items_before.get(idk) is None or items_before[idk]['raw'] != i['raw']]
        self.assertGreaterEqual(len(changed), 1)
        self.assertTrue(any('stale-test body' in c['raw'] for c in changed),
                        [c['raw'][:60] for c in changed])

    def test_rank_does_not_apply_cached_selection(self):
        rows = self.app.catalog()[0]
        zeta_first = self.app.rank(rows, 'zeta')[0]
        zeta_second = self.app.rank(self.app.catalog()[0], 'zeta')[0]
        self.assertEqual(zeta_first['id'], zeta_second['id'])


if __name__ == '__main__':
    unittest.main()
