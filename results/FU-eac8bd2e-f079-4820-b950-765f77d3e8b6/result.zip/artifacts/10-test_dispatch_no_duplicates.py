# Surface 1 NEW checks: same dispatch intent re-submitted concurrently/retried after a
# lost response or a durable claim must never create a second native attempt.
# Distinct from packet tests/test_core.py: mixed submit+claim races, re-submit while
# launching (recovery path), and restart persistence with 24 concurrent submitters.
import concurrent.futures
import tempfile
import unittest
from pathlib import Path

from joi_app_loader import load_app


class DispatchNoDuplicates(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='joi-e-surface1-')
        self.base = Path(self.tmp.name).resolve()
        self.app = load_app(str(self.base))
        self.store = self.app.Store(self.base / 'app' / 'data')

    def tearDown(self):
        self.tmp.cleanup()

    def key(self, n):
        return 'surface1-key-%08d' % n

    def test_mixed_submit_claim_race_claims_launch_once(self):
        job = self.store.draft(self.key(1), {'kind': 'fixture', 'objective': 'Synthetic QA.'})

        def submit_or_claim(i):
            self.store.submit(job['id'])
            return self.store.claim(job['id']) if i % 2 == 0 else False

        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            claims = list(pool.map(submit_or_claim, range(24)))
        self.assertEqual(sum(bool(c) for c in claims), 1)
        self.assertEqual(len(self.store.jobs()), 1)
        self.assertEqual(sum(e['state'] == 'launching'
                             for e in self.store.events(job['id'])), 1)

    def test_resubmit_after_durable_claim_does_not_requeue_or_relaunch(self):
        job = self.store.draft(self.key(2), {'kind': 'fixture', 'objective': 'Synthetic QA.'})
        self.assertTrue(self.store.submit(job['id']) and self.store.claim(job['id']))
        state = self.store.get(job['id'])['state']
        self.assertEqual(state, 'launching')
        # retry of the same intent after lost response
        again = self.store.submit(job['id'])
        self.assertEqual(again['id'], job['id'])
        self.assertEqual(state, 'launching')  # state untouched
        self.assertEqual(sum(e['state'] == 'queued'
                             for e in self.store.events(job['id'])), 1)
        self.assertFalse(self.store.claim(job['id']))
        self.assertEqual(sum(e['state'] == 'launching'
                             for e in self.store.events(job['id'])), 1)

    def test_restart_persistence_keeps_single_queued_event_under_concurrency(self):
        job = self.store.draft(self.key(3), {'kind': 'fixture', 'objective': 'Synthetic QA.'})
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(lambda _: self.store.submit(job['id']), range(24)))
        restarted = self.app.Store(self.base / 'app' / 'data')
        self.assertEqual(len(restarted.jobs()), 1)
        self.assertEqual(restarted.submit(job['id'])['id'], job['id'])
        self.assertEqual(sum(e['state'] == 'queued'
                             for e in restarted.events(job['id'])), 1)
        identical = restarted.draft(self.key(3), {'kind': 'fixture',
                                                  'objective': 'Synthetic QA.'})
        self.assertEqual(identical['id'], job['id'])


    def test_idempotency_payload_mismatch_raises_conflict(self):
        job = self.store.draft(self.key(4), {'kind': 'fixture', 'objective': 'Synthetic QA.'})
        try:
            self.store.draft(self.key(4), {'kind': 'fixture', 'objective': 'CHANGED payload.'})
            self.fail('payload conflict was not detected')
        except self.app.Conflict:
            pass


if __name__ == '__main__':
    unittest.main()
