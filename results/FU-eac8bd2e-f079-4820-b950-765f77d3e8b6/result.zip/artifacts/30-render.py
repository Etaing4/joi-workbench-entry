#!/usr/bin/env python3
"""render.py — rebuild pilot.mp4 from bundled assets with installed FFmpeg.

Run:  python3 -I render.py --output /absolute/path/pilot.mp4      (cwd: G/baseline)

FFmpeg >= 7 recommended (developed/verified with FFmpeg 9.0.2). Reads ONLY the
bundled assets below plus captions.srt; never reads the delivered pilot.mp4;
no network, no model/TTS calls (the narration stem is frozen in narration_segments
and narration.wav). Private scratch is written next to --output.
"""
import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FPS = 24
FILM = 120.0
LUFS_TARGET = -16.0
TP_TARGET = -1.5


def die(msg):
    print('render error: %s' % msg, file=sys.stderr)
    raise SystemExit(2)


def need_tool(name):
    return shutil.which(name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', required=True, help='absolute path for the MP4')
    args = ap.parse_args()
    if not os.path.isabs(args.output):
        die('--output must be an absolute path')
    for t in ('ffmpeg', 'ffprobe'):
        if not need_tool(t):
            die('%s is not on PATH; install FFmpeg (e.g. brew install ffmpeg)' % t)
    out = Path(args.output)
    sched = json.loads((HERE / 'assets' / 'segments_timing.json').read_text())['segments']
    work = Path(tempfile.mkdtemp(prefix='joi-render-'))
    try:
        # 1) narration stem: place frozen espeak segments at their scheduled starts,
        #    then normalize to the target loudness. (No synthesis: segments are frozen.)
        inputs = ['-f', 'lavfi', '-t', str(FILM), '-i', 'anullsrc=r=48000:cl=stereo']
        filt = []
        for i, s in enumerate(sched):
            seg = HERE / 'assets' / 'narration_segments' / ('seg_%02d.wav' % s['idx'])
            if not seg.is_file():
                die('missing frozen narration segment %s' % seg)
            ms = int(round(s['start'] * 1000))
            inputs += ['-i', str(seg)]
            filt.append('[%d:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,'
                        'adelay=%d|%d[a%d]' % (i + 1, ms, ms, i))
        mix = '[0:a]' + ''.join('[a%d]' % i for i in range(len(sched))) + \
            'amix=inputs=%d:duration=first:dropout_transition=0:normalize=0[pre]' % (len(sched) + 1)
        req = (inputs and '') if False else ''
        chain = filt + [mix,
                        '[pre]loudnorm=I=%.1f:TP=%.1f:LRA=11,aresample=48000[lout]' % (LUFS_TARGET, TP_TARGET)]
        narration = work / 'narration.wav'
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'warning', '-y'] + inputs +
                       ['-filter_complex', ';'.join(chain), '-map', '[lout]', '-t', str(FILM),
                        '-c:a', 'pcm_s16le', str(narration)], check=True)
        # 2) video beats: slow push-in on each procedural still, exact frame counts.
        starts = [round(s['start'], 6) for s in sched]
        ends = starts[1:] + [FILM]
        conlist = []
        total_frames = 0
        for i, s in enumerate(sched):
            frames = int(round((ends[i] - starts[i]) * FPS))
            total_frames += frames
            conlist.append((s, frames))
        remainder = int(FILM * FPS) - total_frames
        if remainder:
            s, f = conlist[-1]
            conlist[-1] = (s, f + remainder)
        for i, (s, frames) in enumerate(conlist):
            still = HERE / 'assets' / 'scene_stills' / ('%s.png' % s['still'])
            if not still.is_file():
                die('missing still %s' % still)
            beat = work / ('beat_%02d.mp4' % i)
            subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                            '-loop', '1', '-framerate', str(FPS), '-i', str(still),
                            '-vf', "zoompan=z='zoom+0.0007':d=1:s=1280x720:fps=%d" % FPS,
                            '-frames:v', str(frames), '-c:v', 'libx264', '-preset', 'veryfast',
                            '-crf', '20', '-pix_fmt', 'yuv420p', '-r', str(FPS), str(beat)],
                           check=True)
            conlist[i] = (s, frames, beat)
        lst = work / 'list.txt'
        lst.write_text(''.join("file '%s'\n" % b for (_s, _f, b) in conlist))
        video = work / 'video.mp4'
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat',
                        '-safe', '0', '-i', str(lst), '-c', 'copy', str(video)], check=True)
        # 3) mux: h264 video + AACNarration + embedded mov_text captions.
        tmp_out = work / 'candidate.mp4'
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'warning', '-y',
                        '-i', str(video), '-i', str(narration), '-i', str(HERE / 'captions.srt'),
                        '-map', '0:v', '-map', '1:a', '-map', '2:s', '-c:v', 'copy',
                        '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-c:s', 'mov_text',
                        '-metadata:s:s:0', 'language=eng', '-metadata:s:a:0', 'language=eng',
                        '-disposition:s:0', 'default', '-movflags', '+faststart',
                        '-t', str(FILM), str(tmp_out)], check=True)
        shutil.move(str(tmp_out), str(out))
        print('wrote %s' % out)
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == '__main__':
    main()
