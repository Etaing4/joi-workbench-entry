# Shared loader for E tests: stages the packet app source into an owned temp copy,
# then overrides ROOT-adjacent module constants to owned synthetic fixtures.
# Never touches the packet directory, never imports the production PERSONAL paths,
# and never launches the bridge. All outcomes are labeled synthetic fixtures.
import hashlib
import importlib.util
import shutil
import tempfile
from pathlib import Path

PACKET_APP = Path(__file__).resolve().parents[3] / 'packet' / 'command-center' / 'app.py'
REFERENCE_COPY = Path(__file__).resolve().parent / 'reference_app_copy.py'


def packet_app_sha256():
    return hashlib.sha256(PACKET_APP.read_bytes()).hexdigest()


def load_app(sandbox, source=None):
    """Copy `source` into `sandbox` as app.py, import it, return the module with
    PERSONAL/RUNS/BRIDGE/PUBLIC/CODEX pointed at owned synthetic fixtures.
    Default source: env JOI_APP_SOURCE if set (mutation experiments), else the packet app."""
    import os
    if source is None:
        source = os.environ.get('JOI_APP_SOURCE') or PACKET_APP
    sandbox = Path(sandbox)
    app_dir = sandbox / 'app'
    app_dir.mkdir(parents=True, exist_ok=True)
    staged = app_dir / 'app.py'
    shutil.copyfile(source, staged)
    assert hashlib.sha256(staged.read_bytes()).hexdigest() == hashlib.sha256(Path(source).read_bytes()).hexdigest()
    # synthetic source tree (labeled fixtures, no real content)
    personal = sandbox / 'personal'
    research = personal / 'tasks' / 'rea-jev-research'
    research.mkdir(parents=True, exist_ok=True)
    (personal / 'tasks' / 'OPEN_TASKS.md').write_text(
        'Updated 2026-10-17T08:30:00Z\n'
        '# Synthetic open tasks\n'
        '- **Waiting on owner decision:** fabled AEGIS restore choice; needs owner.\n'
        '  continuation line A\n'
        '  continuation line B\n'
        '- **Blocked:** no such thing in this fixture; also waits.\n'
    )
    (research / 'public-research.md').write_text(
        '# Section Omega\n'
        '- Omega bullet about stale engine routing.\n'
        '\n'
        '# Section Zeta\n'
        'plain paragraph\n'
        '- Zeta bullet on browser agents.\n'
    )
    routing = personal / 'knowledge' / 'ai-adoption' / 'application-routing'
    routing.mkdir(parents=True, exist_ok=True)
    (routing / 'readiness.json').write_text(json.dumps(
        {'observed_at': '2026-10-17T08:00:00Z',
         'applications': {'demo-app': {'state': 'stale / unverified - synthetic'}}}))
    (sandbox / 'outside.md').write_text('SECRET OUTSIDE ALLOWLIST - synthetic canary\n')
    runs = personal / 'runs'
    runs.mkdir(exist_ok=True)
    spec = importlib.util.spec_from_file_location('joi_app_under_test_' + str(id(sandbox)), staged)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    # point every root-adjacent constant at the owned synthetic fixture tree
    mod.PERSONAL = personal
    mod.RUNS = runs
    mod.BRIDGE = sandbox / 'bridge-MOCK-DOES-NOT-EXIST.py'
    mod.CODEX = sandbox / 'codex-MOCK-DOES-NOT-EXIST'
    mod.PUBLIC = {'rea-jev': 'tasks/rea-jev-research/public-research.md',
                  'rea-record': 'tasks/rea-jev-research/record.md'}
    return mod


def write_json(sandbox, relpath, data):
    p = Path(sandbox) / relpath
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data))
    return p


def _apply(text, old, new, count=None):
    assert old in text, old[:60]
    replaced = text.replace(old, new)
    if count is not None:
        assert text.count(old) == count, (old[:40], text.count(old))
    return replaced


MUTANTS = None


def make_mutant(kind, dst):
    """Write a deliberately broken copy of the app source for mutation testing."""
    text = PACKET_APP.read_text()
    if kind == 'surface1-digest-conflict-removed':
        out = _apply(text, "if row['digest'] != digest:\n                raise Conflict('This idempotency key belongs to a different payload')",
                     "if row['digest'] != digest and False:\n                raise Conflict('This idempotency key belongs to a different payload')")
        out = _apply(out, "if row['digest'] != digest:\n                    raise Conflict('Idempotency payload conflict')",
                     "if row['digest'] != digest and False:\n                    raise Conflict('Idempotency payload conflict')")
    elif kind == 'surface3-running-accepted-as-completed':
        out = _apply(text, "state, note = 'unknown-interrupted', 'Running receipt without live bridge lock; child activity is unknown'",
                     "state, note = 'completed', 'receipt observed while running'")
    elif kind == 'surface2-symlink-escape-allowed':
        out = _apply(text, "    current = root\n    for component in path.relative_to(root).parts:\n        current = current / component\n        if current.is_symlink():\n            raise Invalid('Symlink refused')\n    return path",
                     "    return path")
    elif kind == 'surface4-stale-fallback-first-item':
        out = _apply(text, "item = next((x for x in items if x['id'] == ident), None)\n                if item is None:\n                    raise Invalid('Unknown allowlisted evidence')",
                     "item = next((x for x in items if x['id'] == ident), None)\n                if item is None and items: item = items[0]\n                if item is None:\n                    raise Invalid('Unknown allowlisted evidence')")
    else:
        raise ValueError('unknown mutant: ' + kind)
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(out)
    return dst


def make_receipt(app, runs, job_or_id, state='completed', **overrides):
    ident = job_or_id['id'] if isinstance(job_or_id, dict) else job_or_id
    workspace = str(job_or_id['workspace']) if isinstance(job_or_id, dict) else ident
    task = Path(runs) / ident
    attempt = task / 'attempts' / '0001'
    attempt.mkdir(parents=True, exist_ok=True)
    (attempt / 'result.txt').write_text('JOI_FIXTURE_OK: 42')
    r = {'task_id': ident, 'provider': 'codex', 'workspace': workspace,
         'scope': 'read-only', 'model_override': app.MODEL,
         'executable': str(app.CODEX), 'state': state, 'attempt': 1,
         'native_id': '01a148d7-4685-77a0-871a-9b559e820590', 'returncode': 0,
         'started_at': app.now(), 'finished_at': app.now()}
    r.update(overrides)
    (task / 'receipt.json').write_text(json.dumps(r))
    return task


import json  # noqa: E402  (used above; placed here to keep body readable)
