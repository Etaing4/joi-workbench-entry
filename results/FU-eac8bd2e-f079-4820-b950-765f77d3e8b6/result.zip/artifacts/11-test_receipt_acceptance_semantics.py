# Surface 3 NEW checks: a terminal application receipt is not independent task
# acceptance. NEW angles beyond packet tests/test_core.py: string-typed attempt,
# attempt != 1, whitespace-only result text, and replayed foreign-native receipt after
# the canonical attempt-1 native identity is already pinned.
import tempfile
import unittest
from pathlib import Path

from joi_app_loader import load_app, make_receipt


class ReceiptAcceptanceSemantics(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='joi-e-surface3-')
        self.base = Path(self.tmp.name).resolve()
        self.app = load_app(str(self.base))
        self.store = self.app.Store(self.base / 'app' / 'data')
        self.runs = self.app.RUNS

    def tearDown(self):
        self.tmp.cleanup()

    def draft(self, key):
        return self.store.draft(key, {'kind': 'fixture', 'objective': 'Synthetic QA.'})

    def test_string_typed_attempt_never_accepts_completed(self):
        job = self.draft('surface3-str-attempt-0001')
        task = make_receipt(self.app, self.runs, job, attempt='1')
        out = self.store.reconcile(job['id'], self.runs, worker_alive=False)
        self.assertEqual(out['state'], 'unknown-interrupted')
        self.assertFalse(out['operator_completed'])
        self.assertEqual(out['result'], '')
        del task  # fixture, not a live run

    def test_attempt_two_is_never_accepted_side_file(self):
        job = self.draft('surface3-attempt-two-0001')
        task = make_receipt(self.app, self.runs, job, attempt=2)
        out = self.store.reconcile(job['id'], self.runs, worker_alive=False)
        self.assertEqual(out['state'], 'unknown-interrupted')
        self.assertFalse(out['operator_completed'])

    def test_whitespace_only_result_is_not_completion_evidence(self):
        job = self.draft('surface3-ws-result-000001')
        task = make_receipt(self.app, self.runs, job)
        (task / 'attempts' / '0001' / 'result.txt').write_text('   \n\t ')
        out = self.store.reconcile(job['id'], self.runs, worker_alive=False)
        self.assertNotEqual(out['state'], 'completed')
        self.assertFalse(out['operator_completed'])

    def test_running_without_lock_reports_unknown_not_completed(self):
        job = self.draft('surface3-run-nolock-0001')
        make_receipt(self.app, self.runs, job, state='running', returncode=None)
        out = self.store.reconcile(job['id'], self.runs, worker_alive=False)
        self.assertEqual(out['state'], 'unknown-interrupted')
        self.assertIn('without live bridge lock', out['error'])
        self.assertFalse(out['operator_completed'])

    def test_missing_receipt_plus_dead_worker_is_unknown_interrupted(self):
        job = self.draft('surface3-noreceipt-000001')
        self.store.submit(job['id'])
        self.store.claim(job['id'])
        out = self.store.reconcile(job['id'], self.runs, worker_alive=False)
        self.assertEqual(out['state'], 'unknown-interrupted')
        self.assertFalse(out['operator_completed'])

    def test_pinned_native_identity_blocks_replayed_other_native_receipt(self):
        job = self.draft('surface3-replay-native-01')
        make_receipt(self.app, self.runs, job)
        self.assertTrue(self.store.reconcile(job['id'], self.runs,
                                             worker_alive=False)['operator_completed'])
        # foreign native identity claims the same task (labeled synthetic replay)
        make_receipt(self.app, self.runs, job,
                     native_id='ffffffff-ffff-ffff-ffff-ffffffffffff')
        out = self.store.reconcile(job['id'], self.runs, worker_alive=False)
        self.assertEqual(out['state'], 'unknown-interrupted')
        self.assertFalse(out['operator_completed'])


if __name__ == '__main__':
    unittest.main()
