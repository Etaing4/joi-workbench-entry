# submission.py — Joi Workbench follow-up entrant.
# Pure functions for tracks A/B/C/D per packet/ABCD/CONTRACT.md.
# Stdlib only; no I/O, network, clock/random, side-effect imports, input mutation or state.
# Contract requires Python >=3.10; code is kept 3.9-compatible because the authoring host
# runs Python 3.9.6 (recorded in result.json limitations).
import base64
import copy
import datetime as _dt
import hashlib
import json
import re
import ntpath as _ntpath


def _parse_instant(s):
    # Python 3.9 fromisoformat cannot parse a trailing 'Z' (supported from 3.11).
    if isinstance(s, str) and s.endswith('Z'):
        s = s[:-1] + '+00:00'
    return _dt.datetime.fromisoformat(s).astimezone(_dt.timezone.utc)


# ---------------------------------------------------------------- A: operations

_ACTION = {
    'complete': 'none',
    'paused': 'wait_owner',
    'blocked': 'review_receipts',
    'ready_review': 'review_receipts',
    'open': 'prepare_offline',
}


def operations(packet):
    as_of = _parse_instant(packet['as_of'])
    rows = []
    for tid in sorted(set(packet['task_ids'])):
        eligible = []
        for ev in packet['events']:
            if ev.get('task_id') != tid:
                continue
            if ev.get('authority') not in ('operator', 'verified'):
                continue  # narrative-only claims are ignored even if later/superior
            at = _parse_instant(ev['at'])
            if at > as_of:
                continue  # future events ignored, regardless of file order
            eligible.append((at, 1 if ev['authority'] == 'operator' else 0, ev['event_id'], ev))
        if not eligible:
            rows.append({"task_id": tid, "state": "unknown", "worker": None,
                         "native_exit": None, "wrapper_exit": None,
                         "evidence_id": None, "action": "review_receipts"})
            continue
        # greatest actual UTC instant, then authority operator > verified,
        # then lexicographically greatest event_id
        _at, _op, _eid, ev = max(eligible, key=lambda x: (x[0], x[1], x[2]))
        if ev['state'] == 'running':
            action = 'wait_owner' if ev['worker_alive'] else 'review_receipts'
        else:
            action = _ACTION.get(ev['state'], 'review_receipts')
        rows.append({
            "task_id": tid,
            "state": ev['state'],
            "worker": ev['worker'] if ev['worker_alive'] else None,
            "native_exit": ev['native_exit'],
            "wrapper_exit": ev['wrapper_exit'],
            "evidence_id": ev['event_id'],
            "action": action,
        })
    return {"tasks": rows}


# ---------------------------------------------------------------- B: fleet

def fleet(packet):
    as_of = _parse_instant(packet['as_of'])
    budget = packet['budget']
    per_family = packet['per_family']
    report = copy.deepcopy(packet['report'])

    by_identity = {}
    for obs in packet['observations']:
        if obs.get('official') is not True or obs.get('verified') is not True:
            continue
        if not (isinstance(obs.get('model_id'), str) and obs['model_id']):
            continue
        if not (isinstance(obs.get('revision'), str) and obs['revision']):
            continue
        rel = _parse_instant(obs['released_at'])
        if rel > as_of:
            continue
        row = dict(obs)  # private copy; the caller's objects are never mutated
        row['_rel'] = rel
        ident = (row['family'], row['model_id'], row['revision'])
        by_identity.setdefault(ident, []).append(row)

    reps = []
    for rows in by_identity.values():
        reps.append(min(rows, key=lambda r: r['evidence_id']))
    # descending release instant, then ascending family, model_id, revision, evidence_id
    reps.sort(key=lambda r: (-r['_rel'].timestamp(), r['family'], r['model_id'],
                             r['revision'], r['evidence_id']))

    selected, fam_count = [], {}
    for rep in reps:
        fam = rep['family']
        if len(selected) < budget and fam_count.get(fam, 0) < per_family:
            selected.append(rep)
            fam_count[fam] = fam_count.get(fam, 0) + 1
    for rep in reps:
        rep.pop('_rel', None)

    omitted = {}
    for rep in reps:
        if not any(rep is s for s in selected):
            omitted[rep['family']] = omitted.get(rep['family'], 0) + 1
    report['release_observations'] = selected
    report['release_coverage'] = {
        'eligible': len(reps),
        'included': len(selected),
        'omitted': len(reps) - len(selected),
        'omitted_by_family': {k: v for k, v in omitted.items() if v > 0},
    }
    blob = json.dumps(report, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)
    digest = hashlib.sha256(blob.encode('utf-8')).hexdigest()
    return {"report": report, "content_sha256": digest}


# ---------------------------------------------------------------- C: aegis

_BAD_CHARS = ('\x00', '\r', '\n')


def _win_structural_invalid(p):
    """p is invalid as an absolute drive-letter Windows path with backslashes."""
    if not isinstance(p, str) or not p:
        return True
    if any(c in p for c in _BAD_CHARS):
        return True
    if '/' in p:
        return True
    if not (len(p) >= 3 and p[0] in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
            and p[1] == ':' and p[2] == '\\'):
        return True
    if p.startswith('\\\\'):
        return True  # UNC-ish
    components = p[3:].split('\\')
    trailing_empty = 1 if components and components[-1] == '' else 0
    body = components[:-trailing_empty] if trailing_empty else components
    if any(c == '' for c in body):
        return True  # doubled backslashes
    if any(c in ('.', '..') for c in body):
        return True
    return False


def _drive_exists(p):
    # Offline helper: a Windows drive letter "exists" iff one valid A-Z letter names it.
    # No host query, mount table or I/O is consulted (contract is strictly offline).
    if not isinstance(p, str) or not p:
        return False
    return p[0].upper() in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' and bool(re.match(r'^[A-Za-z]:', p))


def _exec_strictly_below(executable, root):
    ce = _ntpath.normcase(_ntpath.normpath(executable))
    cr = _ntpath.normcase(_ntpath.normpath(root))
    if ce == cr:
        return False
    if len(cr) < 2 or not (ce.startswith(cr) and len(ce) > len(cr) and ce[len(cr)] == '\\'):
        return False
    return True


def _plan(owner_state, root, executable, args):
    if owner_state in ('paused', 'busy'):
        return {"status": "blocked", "reason": owner_state}
    if owner_state != 'idle':
        return {"status": "blocked", "reason": str(owner_state)}
    # root must be an absolute drive path; a single trailing backslash is allowed
    root_invalid = _win_structural_invalid(root)
    if root_invalid and root.endswith('\\') and len(root) == 3:
        root_invalid = not _win_structural_invalid(root[:-1])
    if root_invalid:
        return {"status": "invalid", "reason": "path"}
    if not _drive_exists(root):
        return {"status": "invalid", "reason": "path"}
    if _win_structural_invalid(executable):
        return {"status": "invalid", "reason": "path"}
    if not executable.lower().endswith('.exe'):
        return {"status": "invalid", "reason": "path"}
    if not _drive_exists(executable):
        return {"status": "invalid", "reason": "path"}
    if not _exec_strictly_below(executable, root):
        return {"status": "invalid", "reason": "path"}
    for a in args:
        if any(c in a for c in _BAD_CHARS):
            return {"status": "invalid", "reason": "argument"}
    q = lambda s: "'" + s.replace("'", "''") + "'"
    line2 = '& ' + q(executable) + ''.join(' ' + q(a) for a in args)
    text = "$ErrorActionPreference='Stop'\n" + line2 + "\nexit $LASTEXITCODE\n"
    encoded = base64.b64encode(text.encode('utf-16-le')).decode('ascii')
    return {"status": "ready", "script": text, "encoded_command": encoded}


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _receipt(expected_run, expected_sha, receipt):
    if receipt.get('run_id') != expected_run or receipt.get('script_sha256') != expected_sha:
        return {"status": "unknown", "reason": "identity"}
    if receipt.get('timed_out') is True:
        return {"status": "unknown", "reason": "timeout"}
    se = receipt.get('ssh_exit')
    if not _is_int(se):
        return {"status": "unknown", "reason": "transport_missing"}
    if se != 0:
        return {"status": "failed", "reason": "transport"}
    if receipt.get('completed') is not True:
        return {"status": "unknown", "reason": "incomplete"}
    tr = receipt.get('task_result')
    if not _is_int(tr):
        return {"status": "unknown", "reason": "result_missing"}
    if tr != 0:
        return {"status": "failed", "reason": "action"}
    return {"status": "succeeded", "reason": "verified"}


def aegis(packet):
    op = packet.get('op')
    if op == 'plan':
        return _plan(packet['owner_state'], packet['root'], packet['executable'],
                     packet['args'])
    if op == 'receipt':
        return _receipt(packet['expected_run'], packet['expected_script_sha256'],
                        packet['receipt'])
    raise ValueError('unknown aegis op: %r' % (op,))


# ---------------------------------------------------------------- D: documents

_ACC = re.compile(r'^[0-9]{8,12}$')
_BAL1 = re.compile(r'^Ending balance: USD ([0-9]{1,3}(?:,[0-9]{3})*)\.([0-9]{2})$')
_BAL2 = re.compile(r'^Closing balance USD ([0-9]+)\.([0-9]{2})$')


def _quote_cents(quote):
    m = _BAL1.match(quote)
    if m:
        groups = m.group(1).split(',')
        if len(groups) > 1 and (groups[0] == '0' or groups[0].startswith('0')):
            return None
        return int(''.join(groups)) * 100 + int(m.group(2))
    m = _BAL2.match(quote)
    if m:
        whole = m.group(1)
        if len(whole) > 1 and whole.startswith('0'):
            return None
        return int(whole) * 100 + int(m.group(2))
    return None


def _balance_of(doc):
    """Integer cents iff doc has a valid balance citation on an existing page."""
    bal = doc.get('balance')
    if not isinstance(bal, dict):
        return None
    page, quote = bal.get('page'), bal.get('quote')
    by_page = {p.get('page'): p.get('text') for p in doc.get('pages', [])}
    if not isinstance(quote, str) or page not in by_page:
        return None
    if quote not in str(by_page[page]).split('\n'):
        return None
    return _quote_cents(quote)


def _id_field(v):
    return isinstance(v, str) and v != ''


def _plausible(identity, req):
    for k in ('bank', 'account', 'period'):
        v = identity.get(k)
        if not _id_field(v):
            continue  # unknown: null/empty
        if k == 'account' and _ACC.match(v) is None:
            continue  # masked/suffix account is UNKNOWN, never exact identity
        if v != req[k]:
            return False
    return True


def _exact_against_req(identity, req):
    return all(identity.get(k) == req[k] for k in ('bank', 'account', 'period'))


def _identity_equal(a, b):
    return all(a.get(k) == b.get(k) for k in ('bank', 'account', 'period'))


def _abstract_usable(doc):
    """Usable in the abstract: fully specified identity + valid balance citation."""
    ident = doc.get('identity', {})
    return all(_id_field(ident.get(k)) for k in ('bank', 'account', 'period')) and \
        _balance_of(doc) is not None


def documents(packet):
    docs = packet['documents']
    # 1) exact-duplicate elimination: identical JSON excluding id; page order matters
    sig_groups = {}
    for d in docs:
        sig = json.dumps({k: v for k, v in d.items() if k != 'id'}, sort_keys=True,
                         separators=(',', ':'), ensure_ascii=False)
        sig_groups.setdefault(sig, []).append(d['id'])
    rep_of = {}
    canon_ids = []
    for ids in sig_groups.values():
        rep = min(ids)
        canon_ids.append(rep)
        for i in ids:
            rep_of[i] = rep
    by_id = {d['id']: d for d in docs}

    def resolve(docid):
        return rep_of.get(docid, docid)

    # 2) supersession: a usable replacement erases a target with EXACT SAME identity
    superseded = set()
    for cid in canon_ids:
        d = by_id[cid]
        if not _abstract_usable(d):
            continue  # an unusable replacement cannot erase old evidence
        for t in d.get('supersedes', []):
            tr = resolve(t)
            if tr == cid or tr not in canon_ids or tr in superseded:
                continue
            if _identity_equal(by_id[tr].get('identity', {}), d.get('identity', {})):
                superseded.add(tr)

    active = sorted(cid for cid in canon_ids if cid not in superseded)

    rows = []
    for req in packet['requirements']:
        plausible = [cid for cid in active if _plausible(by_id[cid].get('identity', {}), req)]
        usable = [cid for cid in plausible
                  if _balance_of(by_id[cid]) is not None
                  and _exact_against_req(by_id[cid].get('identity', {}), req)]
        evidence = sorted(({"document_id": c, "page": by_id[c]['balance']['page'],
                            "quote": by_id[c]['balance']['quote']} for c in usable),
                          key=lambda e: e['document_id'])
        if not plausible:
            rows.append({"id": req['id'], "status": "missing",
                         "amount_cents": None, "evidence": []})
        elif len(usable) != len(plausible):
            rows.append({"id": req['id'], "status": "needs_review",
                         "amount_cents": None, "evidence": evidence})
        else:
            cents = _balance_of(by_id[usable[0]])
            distinct = {_balance_of(by_id[c]) for c in usable}
            if len(distinct) > 1:
                rows.append({"id": req['id'], "status": "conflicting",
                             "amount_cents": None, "evidence": evidence})
            else:
                rows.append({"id": req['id'], "status": "available",
                             "amount_cents": cents, "evidence": evidence})
    return {"requirements": rows}
