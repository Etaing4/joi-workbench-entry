# Surface 2 NEW checks: evidence paths must never escape the allowlisted tree.
# NEW beyond packet tests: out-of-allowlist synthetic canary file is invisible to any
# catalog/search/evidence query; percent-encoded traversal ids stay rejected at the
# evidence endpoint; evidence ids never expose absolute filesystem paths.
import json
import tempfile
import threading
import unittest
import urllib.parse
from pathlib import Path

from joi_app_loader import load_app


class EvidenceAllowlist(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='joi-e-surface2-')
        self.base = Path(self.tmp.name).resolve()
        self.app = load_app(str(self.base))
        self.store = self.app.Store(self.base / 'app' / 'data')
        self.server = self.app.ThreadingHTTPServer(('127.0.0.1', 0), self.app.Handler)
        self.server.service = self.app.Service(self.store)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.host = '127.0.0.1:%s' % self.server.server_port
        import urllib.request
        import http.cookiejar
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        status, data = self.request('GET', '/api/session', auth=False)
        self.assertEqual(status, 200)
        self.token = data['token']

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.tmp.cleanup()

    def request(self, method, path, body=None, auth=True):
        import urllib.request
        import urllib.error
        url = 'http://' + self.host + path
        headers = {'Host': self.host}
        if auth:
            headers['X-Joi-Token'] = self.token
            headers['Origin'] = 'http://' + self.host
        data = json.dumps(body).encode() if body is not None else None
        if data is not None:
            headers['Content-Type'] = 'application/json'
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=5) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            try:
                return exc.code, json.loads(exc.read().decode())
            except Exception:
                return exc.code, None

    def test_out_of_allowlist_canary_never_appears_in_search(self):
        for query in ('SECRET', 'canary', 'outside', 'leak', 'browser agents', 'zeta'):
            status, payload = self.request('GET', '/api/search?q='
                                           + urllib.parse.quote(query) + '&kind=all')
            self.assertEqual(status, 200)
            self.assertTrue(all('outside' not in i['id'] and 'canary' not in i['raw'].lower()
                                and 'SECRET' not in i['raw']
                                for i in payload['items']), query)

    def test_encoded_traversal_evidence_ids_are_unknown_not_resolved(self):
        for bad in ('..%2F..%2Foutside.md', 'task%3A%2E%2E', '..%5Coutside.md',
                    'research%3A..%3A1'):
            status, payload = self.request('GET', '/api/evidence/' + bad)
            self.assertEqual(status, 400, bad)
            if payload:
                self.assertIn('error', payload)

    def test_evidence_ids_contain_no_filesystem_paths(self):
        status, payload = self.request('GET', '/api/search?q=zeta&kind=research')
        self.assertEqual(status, 200)
        items = payload['items']
        self.assertTrue(items)
        for item in items:
            self.assertFalse(item['id'].startswith('/'))
            self.assertNotIn(str(self.app.PERSONAL), item['id'])
        status, ev = self.request('GET', '/api/evidence/'
                                  + urllib.parse.quote(items[0]['id']))
        self.assertEqual(status, 200)
        self.assertNotIn(str(self.app.PERSONAL), ev['raw'])
        self.assertEqual(ev['id'], items[0]['id'])

    def test_store_path_helpers_reject_root_escapes(self):
        personal = self.app.PERSONAL
        with self.assertRaises(self.app.Invalid):
            self.app.safe_path(personal, '..', 'outside.md')
        with self.assertRaises(self.app.Invalid):
            self.app.safe_path(personal, 'a', '..', '..', 'outside.md')
        # symlink escape inside the root points outside the allowlisted tree
        link = personal / 'linkout'
        try:
            link.unlink()
        except FileNotFoundError:
            pass
        link.symlink_to(self.app.PERSONAL.parent / 'outside.md')
        with self.assertRaises(self.app.Invalid):
            self.app.safe_path(personal, 'linkout')


if __name__ == '__main__':
    unittest.main()
