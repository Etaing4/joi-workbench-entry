#!/usr/bin/env python3
"""Procedural stills for 'Sign-Off'. Pure stdlib; original abstract scene art."""
import math, struct, zlib, os
from pathlib import Path

W, H = 1280, 720
OUT = Path('/tmp/gwork/stills'); OUT.mkdir(exist_ok=True)

def png(path, pix):
    rows = b''.join(b'\x00' + bytes(pix[y]) for y in range(H))
    def chunk(t, d):
        return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    hdr = struct.pack('>IIBBBBB', W, H, 8, 2, 0, 0, 0)
    data = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', hdr) + chunk(b'IDAT', zlib.compress(rows, 6)) + chunk(b'IEND', b'')
    path.write_bytes(data)

def base(bgr, bgg, bgb):
    pix = [bytearray([bgr, bgg, bgb]) * W for _ in range(H)]
    return pix

def vgrad(pix, top, bottom):
    for y in range(H):
        t = y / (H - 1)
        r = top[0] * (1 - t) + bottom[0] * t
        g = top[1] * (1 - t) + bottom[1] * t
        b = top[2] * (1 - t) + bottom[2] * t
        pix[y][:] = (int(r), int(g), int(b)) * W

def rec(pix, x0, y0, x1, y1, col):
    for y in range(max(0, y0), min(H, y1)):
        row = pix[y]
        for x in range(max(0, x0), min(W, x1)):
            row[3 * x], row[3 * x + 1], row[3 * x + 2] = col

def dot(pix, cx, cy, r, col):
    for y in range(int(cy - r) - 2, int(cy + r) + 3):
        if 0 <= y < H:
            row = pix[y]
            for x in range(int(cx - r) - 2, int(cx + r) + 3):
                if 0 <= x < W and (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    row[3 * x], row[3 * x + 1], row[3 * x + 2] = col

def line(pix, x0, y0, x1, y1, col, w=1):
    n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
    for i in range(n):
        t = i / max(1, n - 1)
        x, y = int(x0 + (x1 - x0) * t), int(y0 + (y1 - y0) * t)
        rec(pix, x, y - w // 2, x + 1, y + w // 2 + 1, col)

AMBER, RED, BLUE, TEAL, WHITE, GREY, DIM = (244, 176, 66), (208, 62, 52), (66, 120, 200), (52, 190, 176), (235, 240, 240), (120, 132, 140), (36, 42, 50)

def s1_hook():
    p = base(10, 10, 12); vgrad(p, (8, 9, 12), (2, 2, 3))
    rec(p, 612, 340, 668, 380, AMBER)
    rec(p, 618, 346, 662, 374, (24, 22, 14))
    line(p, 40, 640, 1240, 640, (28, 30, 34), 2)
    png(OUT / 's1_hook.png', p)

def s2_world():
    p = base(8, 12, 20); vgrad(p, (10, 16, 30), (3, 6, 12))
    for gy in range(0, 720, 60):
        line(p, 0, gy, W - 1, gy, (20, 30, 52), 1)
    for gx in range(0, 1280, 80):
        line(p, gx, 0, gx, H - 1, (20, 30, 52), 1)
    import random
    random.seed(7)
    for i in range(300):
        x = random.uniform(90, 1190); y = random.uniform(120, 640)
        col = TEAL if random.random() < 0.92 else BLUE
        dot(p, x, y, 3.2, col)
        if random.random() < 0.08:
            line(p, x, y, x + 10, y - 8, DIM, 1)
    dot(p, 1010, 210, 7, RED); dot(p, 940, 250, 7, RED)
    rec(p, 40, 24, 300, 74, (18, 24, 36))
    png(OUT / 's2_world.png', p)

def s2_perfect():
    p = base(8, 12, 20); vgrad(p, (12, 18, 34), (4, 7, 14))
    for gy in range(0, 720, 60):
        line(p, 0, gy, W - 1, gy, (22, 34, 60), 1)
    for i in range(30):
        for j in range(10):
            dot(p, 110 + i * 38, 150 + j * 45, 3.0, TEAL)
    for i in range(30):
        dot(p, 110 + i * 38, 330, 5.5, TEAL)
    dot(p, 110 + 17 * 38, 330, 8.0, AMBER)
    rec(p, 40, 24, 470, 74, (18, 24, 36))
    png(OUT / 's2_perfect.png', p)

def s3_math():
    p = base(10, 9, 11); vgrad(p, (16, 13, 15), (6, 5, 7))
    line(p, 640, 120, 640, 640, (70, 74, 82), 2)   # now-line
    line(p, 120, 640, 1160, 640, (70, 74, 82), 2)
    for i in range(9):
        x = 700 + i * 55
        dot(p, x, 180 + 20 * (i % 3), 5, RED)
        line(p, x, 180 + 20 * (i % 3), x, 640, (90, 40, 38), 1)
    for i in range(9):
        x = 700 + i * 55
        dot(p, x - 22, 430, 4, AMBER)   # signed BEFORE the ship exists
    rec(p, 40, 24, 380, 74, (18, 18, 22))
    png(OUT / 's3_math.png', p)

def s3_script():
    p = base(16, 16, 18); vgrad(p, (18, 18, 20), (8, 8, 9))
    for r in range(14):
        y = 90 + r * 40
        for c in range(12):
            x0 = 120 + c * 92
            if r % 2 == c % 2:
                pass
            line(p, x0, y, x0 + 70, y, RED, 2)
            line(p, x0 + 70, y, x0 + 88, y - 12, RED, 2)
        line(p, 90, y + 18, 1190, y + 18, (34, 34, 38), 1)
    png(OUT / 's3_script.png', p)

def s4_blank():
    p = base(6, 8, 9); vgrad(p, (7, 9, 11), (3, 4, 5))
    rec(p, 160, 140, 1120, 560, (16, 19, 23))
    rec(p, 176, 156, 1104, 544, (9, 11, 13))
    for i in range(6):
        line(p, 220, 210 + i * 28, 560 + (i * 37) % 380, 210 + i * 28, (26, 30, 34), 1)
    rec(p, 214, 388, 230, 404, TEAL)   # lone cursor
    png(OUT / 's4_blank.png', p)

def s4_choice():
    p = base(6, 7, 8); vgrad(p, (10, 12, 14), (4, 5, 6))
    rec(p, 120, 160, 580, 600, (26, 22, 20))
    rec(p, 700, 160, 1160, 600, (16, 22, 28))
    line(p, 120, 160, 580, 600, (60, 40, 30), 3); line(p, 580, 160, 120, 600, (60, 40, 30), 3)
    line(p, 700, 160, 700, 600, (26, 36, 48), 2)
    line(p, 740, 430, 1120, 430, TEAL, 3)   # the one signed line
    rec(p, 820, 492, 1040, 516, AMBER)
    png(OUT / 's4_choice.png', p)

def s4_audit():
    p = base(12, 12, 14); vgrad(p, (14, 15, 17), (6, 6, 7))
    for i in range(12):
        y = 120 + i * 40
        line(p, 180, y, 640, y, (56, 58, 62), 1)
        line(p, 660, y, 1100, y, (44, 46, 50), 1)
    line(p, 180, 280, 640, 280, AMBER, 3); line(p, 180, 520, 640, 520, AMBER, 3)
    rec(p, 660, 520, 1100, 544, (120, 90, 30))
    png(OUT / 's4_audit.png', p)

def s5_report():
    p = base(14, 14, 15); vgrad(p, (18, 18, 20), (9, 9, 10))
    rec(p, 300, 90, 980, 640, (226, 228, 224))
    rec(p, 300, 90, 980, 120, (180, 184, 182))
    for i in range(11):
        y = 170 + i * 44
        w = (560, 520, 560, 480, 560, 300, 560, 540, 120, 100)[i % 10]
        line(p, 350, y, 350 + w, y, (150, 152, 150), 2)
    line(p, 350, 458, 930, 458, (192, 100, 40), 4)   # the one line
    rec(p, 350, 486, 470, 530, TEAL)
    png(OUT / 's5_report.png', p)

def s5_port():
    p = base(10, 12, 16); vgrad(p, (16, 22, 34), (5, 7, 11))
    for k in range(4):
        x = 200 + k * 240
        rec(p, x, 300, x + 140, 380, (26, 32, 42))
        rec(p, x + 50, 240, x + 90, 300, (30, 38, 48))
        dot(p, x + 70, 218, 7, RED if k % 2 else TEAL)
    rec(p, 60, 640, 1220, 700, (20, 26, 34))
    rec(p, 60, 620, 1220, 640, TEAL)   # sealed bar
    for i in range(12):
        x = 100 + i * 98
        dot(p, x, 580, 6, (60, 70, 80) if i % 3 else AMBER)
    png(OUT / 's5_port.png', p)

STILLS = dict(s1=s1_hook, s2=s2_world, s2b=s2_perfect, s3=s3_math, s3b=s3_script,
              s4=s4_blank, s4b=s4_choice, s4c=s4_audit, s5=s5_report, s5b=s5_port)

if __name__ == '__main__':
    for name, fn in STILLS.items():
        fn()
        print('wrote', name)
