# Code authorship evidence
- calculator.py and landing/index.html were authored during this single agent session
  (FU entry FU-eac8bd2e-f079-4820-b950-765f77d3e8b6, harness Freebuff Desktop) on
  2026-10-18 and tested by the commands in README.md.
- calculator.py interface matches packet/contracts/TRACK_F.md exactly (ten keys in,
  seven keys out, exit semantics).
- No external dependency beyond Python stdlib is imported; no portion copied from
  third-party code.
