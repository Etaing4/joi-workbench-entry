# REPRODUCE.md — 'Sign-Off' pilot

## Toolchain (observed on the authoring host)
- eSpeak NG 1.52.0 (`espeak-ng -v en-us -s 140`), used once at authoring time to make
  the frozen narration segments (assets/narration_segments/seg_00..35.wav).
- FFmpeg 9.0.2 / FFprobe 9.0.2 (/opt/homebrew/bin).
- Python 3.9.6 stdlib only for stills generation (assets/make_stills.py) and render.py.
- No music. No fonts. No external sample/model. No MBROLA voice.

## One-shot regeneration
```
cd <G/baseline directory>
python3 -I render.py --output /absolute/path/pilot.mp4
```
render.py (stdlib only, verified above) rebuilds the exact timeline from bundled assets:
- narration.wav: frozen espeak segments placed at their scheduled starts (assets/
  segments_timing.json), amix over a silent base, loudnorm I=-16.0 TP=-1.5 LRA=11.
- video: 36 beats = slow zoompan push-in (z 0.0007/frame) over bundled procedural
  stills (assets/scene_stills/*.png), concatenated, frame-count exact to 2880 frames
  @24 fps = 120.0 s; libx264 crf 20.
- mux: H.264 video + AAC 160k audio + embedded mov_text captions from captions.srt
  (language=eng, default disposition).

## Frame rate / seeds / timing
- 24 fps; film length exactly 120.0 s; first speech at 1.208 s; inter-sentence gap
  0.45 s; inter-scene gap 1.6 s.
- Stills are deterministic (fixed seed 7 in assets/make_stills.py only for ship-dot
  scatter in s2_world.png); render.py itself needs no seed.
- The synthesis step is NOT repeated on rerun: the narration stem is frozen, as the
  policy requires ("Freeze the real resulting WAV in your bundle").

## Delivery timeline (measured, seconds)
| scene | start | content |
|-------|-------|---------|
| S1 hook | 1.21 | sign-off never loads |
| S2 world | 11.12 | Kestrel-9, 300 signed ships |
| S3 mechanism | 42.96 | forged timeline +30s |
| S4 choice | 73.71 | bury or sign |
| S5 turn/payoff | 97.54 | report out, port sealed, question |

## Verification already run on the delivered mp4
- ffprobe: container 120.000 s; v: h264 1280x720 24fps; a: aac 48k stereo 120.000 s;
  s: mov_text eng default, 119.747 s (within 0.5 s).
- ebur128 (mixed audio): I = -16.1 LUFS, true peak -1.3 dBFS; stem: I = -16.0 LUFS.
- silencedetect (-40 dB): no silence gap >= 0.3 s across the film (speech 1.2-119.6 s).
- Rerender comparison: `python3 -I render.py --output /tmp/reproduce.mp4` ->
  identical stream layout, identical duration, decoded audio PCM identical
  (`cmp` on decoded s16le digests).

## Known limitations
- Human listening of the film was not performed in-session; intelligibility/sync were
  only verified via measurements and the frozen-timeline construction.
- AAC encode of the same PCM is deterministic on this host build; on other FFmpeg
  builds the muxed file hash may differ even with identical decoded frames/PCM.
