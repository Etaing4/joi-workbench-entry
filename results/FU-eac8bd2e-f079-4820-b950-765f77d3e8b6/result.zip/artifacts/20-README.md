# Friday Status Kit — F baseline README

## What this bundle is
A reusable economic-value kit for a narrow, nonregulated buyer (solo data/analytics
consultants who write weekly client status reports). It contains the offer, a fully
synthetic completed sample, an offline landing page, and an offline unit-economics
calculator. All money figures are **modeled estimates, not earned revenue**. No
customer contact, marketing, or publication has been performed.

## Calculator usage (exact interface)
One JSON object on stdin, exactly ten numeric keys (see calculator.py docstring),
exactly one JSON object on stdout, exit 0. Invalid input → exit != 0 + stderr
explanation.

```sh
echo '{"price_usd":600,"leads":12,"conversion_rate":0.25,"refund_rate":0.05,
"fee_rate":0.03,"variable_cost_per_order_usd":20,"labor_minutes_per_order":150,
"hourly_labor_usd":120,"fixed_cost_usd":80,"acquisition_cost_usd":400}' |
python3 calculator.py
```

Model (fixed by the track contract): expected_orders = leads × conversion_rate;
unit_net = price × (1−refund) × (1−fee); unit_fulfillment = variable +
labor_minutes/60 × hourly; profit subtracts fixed and acquisition costs;
break-even uses ceil(fixed+acquisition over per-order contribution) and is null
when contribution ≤ 0; cac uses acquisition/expected_orders.

## Scenarios (referenced in submission.json)
- **low:** fewer/better-hedged demand (6 leads, 15% conv), heavier fulfillment
  (40 variable USD, 240 min/kit), costlier acquisition (800 USD).
- **base:** 12 leads, 25% conversion, 150 minutes of setup labor per kit.
- **high:** stronger funnel (24 leads, 35% conv), leaner fulfillment, better price
  (750 USD), cheaper acquisition (200 USD).
Demand/conversion vary across scenarios as does labor intensity (a cost lever) —
per contract the intents are demand-uncertainty and fulfillment-efficiency spread.

## Customization
Edit `offer.md` (price, inclusions), re-run the calculator with your own ten inputs,
and adjust scenario rows in `submission.json` accordingly. The calculator hard-codes
no business numbers.

## Limitations and honest distinctions
- All demand, conversion and pricing values are **assumed**; the anecdotal pain
  quotes in `offer.md` are directional public evidence, not market measurement.
- Measured quantities in `measurement-log.json` are production time and tool
  versions only; unmeasured entries are recorded as null/unmeasured.
- Omitted from the model: taxes, working-capital timing, platform/marketplace fees
  beyond `fee_rate`, refund administration effort, currency effects.
- Modeled value ≠ revenue earned: no sales occurred during this experiment.
- Landing CTA is deliberately disabled (demo build, no purchase/payment rails).
- No recurring costs were incurred; the authoring model entitlement is pre-existing.

## Next validation step (proposed, not executed)
Record a 3-minute screencast of the sample generator run and show it to **five**
working solo analytics consultants via an existing professional community thread,
asking only "would this save you Friday time; what's missing?" — results logged as
hypothesis evidence. No selling, no prices in the outreach.
