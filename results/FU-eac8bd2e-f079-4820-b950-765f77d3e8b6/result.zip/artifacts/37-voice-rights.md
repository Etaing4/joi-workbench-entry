# Voice rights evidence (G)
- Tool: eSpeak NG 1.52.0 (default en-us formant voice, no MBROLA), installed at
  /opt/homebrew/Cellar/espeak-ng/1.52.0. Exact command per segment:
  `espeak-ng -v en-us -s 140 -w seg_NN.wav "<text>"`.
- Narration text: original script by the authoring session (see narration.txt);
  nothing copied from protected works.
- GPL position (from packet common/MEDIA_POLICY.md, retained sources hold the eSpeak
  NG README/COPYING/GNU GPL FAQ): GPL-3.0-or-later permits commercial use; GNU GPL
  output FAQ treats the voice output of a program run on one's own input as not
  covering the program's copyright into the result, so per the policy the generated
  English formant audio is treated as entrant-own content with tool attribution; the
  rationale is source-backed but NOT a legal warranty, and remains subject to
  arbiter review. Corresponding-source of the tool remains publicly available under
  GPL; no proprietary claim over the tool itself is made.
- commercial_allowed/derivatives_allowed: true (per this documented rationale).
- Limitation: no human verification of intelligibility/sync in-session; policy caps
  (no voice clones, no MBROLA) respected.
