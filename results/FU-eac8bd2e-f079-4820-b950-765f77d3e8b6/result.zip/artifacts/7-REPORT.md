# E — Command Center independent QA report

Trait: FU-eac8bd2e-f079-4820-b950-765f77d3e8b6 (cohort FOLLOWUP-d93d4d99-c7ea-4c81-94a0-4e8840a2ccfd).

## Scope, isolation and limits

Subject is the packet's isolated `packet/command-center/` copy (app.py sha256
`bb0b048e21461a768d0dd2759bf34ebed52c6b111a88370caeb509162ac972b3`, matching
SOURCE_MANIFEST.json). Per command-center/README.md this suite:

- never started app.py's production serve/worker entrypoints or invoked the bridge;
- staged its own temp copy of the app source, overriding PERSONAL/RUNS/BRIDGE/PUBLIC/CODEX
  to owned synthetic fixtures before any call (see tests/joi_app_loader.py) so no source
  lookup can reach the host's real Documents path;
- used no provider, no network, no package installs; Python 3.9.6 stdlib only;
- ran one owned ephemeral loopback server on port 0 for the HTTP-surface checks
  (surface 2), plus direct Store-level checks; no port 8769 was touched;
- disabled real dispatch: the bridge path is a nonexistent mock so `worker()` could
  never launch a native process; all receipt outcomes are labeled synthetic fixtures.

## New coverage (17 checks, 4 test modules)

Deliberately none of these duplicate packet tests/test_core.py or test_http.py:

- **surface 1 — duplicate dispatch (test_dispatch_no_duplicates.py, 4 checks)**:
  mixed submit+claim race from 24 threads must claim exactly one durable launch;
  re-submission after a durable claim must not requeue/relock; restart persistence
  of a single queued event under concurrency; identical-key different-payload must
  raise Conflict (idempotency digest).
- **surface 3 — receipt is not acceptance (test_receipt_acceptance_semantics.py, 6 checks)**:
  string-typed `attempt`, attempt=2, whitespace-only result, running-receipt without a
  live bridge lock, missing receipt with dead worker, and a replayed receipt carrying a
  foreign native UUID after attempt-1 identity is pinned — all must stay
  `unknown-interrupted`/`failed` with `operator_completed=false` and never accept.
- **surface 2 — evidence allowlist (test_evidence_allowlist.py, 4 checks)**: a synthetic
  canary file outside the allowlist is invisible to every search query; percent-encoded
  traversal evidence ids are rejected at the HTTP endpoint; evidence ids/responses
  never embed absolute filesystem paths; `safe_path` rejects `..` climb and symlink
  escapes aimed outside the tree.
- **surface 4 — stale search selection (test_search_selection_staleness.py, 3 checks)**:
  after the source file grows, previously displayed evidence ids stop resolving to the
  same content (the server re-anchors by line), edited content is reachable under the
  new anchors, and repeated rank() calls never apply a cached selection.

## Mutation demonstration (mutation resistance)

`tests/run_all.py` additionally runs four deliberately broken copies of the app
(generated from the pristine source, single-behavior edits recorded as JSON data):

| Mutant | Baseline behavior removed | Caught by |
|---|---|---|
| surface1-digest-conflict-removed | idempotency payload-conflict digest check | test_idempotency_payload_mismatch_raises_conflict |
| surface3-running-accepted-as-completed | running-without-lock must not complete | test_running_without_lock_reports_unknown_not_completed |
| surface2-symlink-escape-allowed | per-component symlink rejection in safe_path | test_store_path_helpers_reject_root_escapes |
| surface4-stale-fallback-first-item | unknown evidence id must stay rejected | test_encoded_traversal_evidence_ids_are_unknown_not_resolved |

Every mutant made its designated module fail while the pristine suite passed 100%
(observed exits recorded in E/TEST_RESULTS.json, key `caught_mutation`).

## Baseline defects

No new baseline defect was confirmed. One **pre-existing testability trap** worth
recording: `Store` rejects data directories whose absolute path does not literally
contain the unresolved ROOT, so a temp dir under `/var/folders` (symlink to
`/private/var` on macOS) cannot host the store even when `resolve()` places it below
ROOT (app.py Store.__init__, line ~218). Receipt_root already handles this class of
alias for receipts; Store does not. Not patched: it is benign in the real layout and
a patch would only help fixtures. Recorded as candidate patch.py note in TEST_RESULTS.

The old suite already covers much of surfaces 0–3 thoroughly; the value added here is
the missing staleness surface (4), the foreign-native replay case, the
out-of-allowlist canary, and concurrency/restart shapes the old tests do not cover.

## UI caveat (honest limitation)

Surface 4 was verified at the API/data layer only. No browser receipts were captured
(GUI/browser use was outside this session's available tooling), so UI rendering of
search/selection is *not* claimed as browser-verified. Static assets were not asserted.

## Reproduce

```
cd output/E/tests && python3 run_all.py
```
Prerequisite: the full participant packet exists three levels up (packet/command-center/app.py).
All outputs land in E/TEST_RESULTS.json.
