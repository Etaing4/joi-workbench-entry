# F rights and authorship evidence

## Rights rows (mirrored in submission.json `rights` array)
1. **calculator.py** — code — status: original. Creator: authoring agent session
   (FU-eac8bd2e-f079-4820-b950-765f77d3e8b6) inside Freebuff Desktop, 2026-10-18.
   License to grant: MIT-style permission notice below; commercial and derivative use
   allowed. Evidence: this file + `code-authorship.md`.
2. **landing/index.html** — visual/code — status: original, hand-written inline CSS,
   system font stack only (no font files shipped), no assets from third parties.
   Commercial/derivative use allowed. Evidence: `code-authorship.md`.
3. **sample.md / sample/sample.md / offer.md / README.md** — script/text — status:
   original. All names, companies and numbers are invented; the two pain quotes are
   short attributed public excerpts cited with URL and access date (fair-use-style
   quotation, not republished wholesale). Evidence: `quotes-sources.md`.
4. **measurement-log.json** — other — status: original session record.

## License grant text proposed to buyers
"Kit owner retains base framework; buyer receives a perpetual, worldwide,
royalty-free internal license to use and modify all delivered outputs, including
commercial use and derivative works. The two cited public quotes remain the words of
their original authors."

## Explicit non-claims
- No third-party code, fonts, images, music or voice is included in track F.
- No relicensing claim is made about the quoted public posts (still owned by their authors).
- Public availability (the cited URLs) does not equal public domain.
