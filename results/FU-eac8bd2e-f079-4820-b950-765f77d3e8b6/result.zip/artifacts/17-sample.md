# Sample — completed weekly status kit for the synthetic client "Lumen Retail Co."

*(Fully synthetic example: Lumen Retail Co., its people and numbers are invented for
demonstration.)*

**Client context:** Lumen Retail Co. runs two Shopify stores. The analytics consultant
(Jordan M., solo, $120/h target rate) agreed with client ops lead **Priya R.** on three
Friday metrics: weekly revenue, ad-attributed revenue share, and open CX tickets older
than 7 days.

## What the kit generated

`friday_status.py` (delivered in the client's own repo) reads three CSV exports the
ops lead already downloads weekly and renders `lumen_weekly_w42.md`:

```markdown
# Lumen Retail Weekly — W42 (Oct 5–11, 2026)
| metric                        | this week | last week | trend | note                |
|-------------------------------|----------:|----------:|-------|---------------------|
| Weekly revenue (USD)          |    18,240 |    16,930 | +7.7% | two promo slots live|
| Ad-attributed revenue share   |    38.1%  |    41.2%  | -3.1pt| promo skews organic |
| CX tickets open >7d           |        14 |        22 | -36.4%| holiday staffing    |
## Risks / asks
- Attribution share dropped while spend held flat; confirm promo code exclusions before Monday.
- Asking ops for final holiday staffing plan by Wed to size CX coverage.
```

## Reuse outcome (modeled, not measured on live client)
- First setup with the kit: ~90 minutes.
- Each subsequent Friday: 7 minutes (download CSVs, run script, skim output).
- At Jordan's $120/h and one client, weekly savings ≈ 1h50m ≈ $220/wk during an
  engagement; the $600 kit pays back in <3 weeks per client, then compounds across
  the second and third client (marginal setup time shrinks to ~45 minutes).
