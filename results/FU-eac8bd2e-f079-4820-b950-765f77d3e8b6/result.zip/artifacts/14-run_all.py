# E runner: (1) run all new checks against the pristine packet app source;
# (2) run each mutant and demonstrate that its designated check FAILS on the mutant.
# Machine-writes E/TEST_RESULTS.json with actual commands and observed outcomes.
import io
import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
from joi_app_loader import PACKET_APP, packet_app_sha256, make_mutant


def run_module(module_name, source=None):
    cmd = [sys.executable, '-E', '-s', str(HERE / module_name)]
    env = dict(os.environ)
    if source is not None:
        env['JOI_APP_SOURCE'] = str(source)
    proc = subprocess.run(cmd, cwd=str(HERE), env=env, capture_output=True,
                          text=True, timeout=300)
    return {'module': module_name,
            'command': 'JOI_APP_SOURCE=%s python3 -E -s %s' % (source or '<pristine>', module_name),
            'exit': proc.returncode,
            'tail': (proc.stdout + proc.stderr)[-1500:]}


MODULES = [
    'test_dispatch_no_duplicates.py',
    'test_receipt_acceptance_semantics.py',
    'test_evidence_allowlist.py',
    'test_search_selection_staleness.py',
]

MUTANTS = [
    ('surface1-digest-conflict-removed', 'test_dispatch_no_duplicates.py'),
    ('surface3-running-accepted-as-completed', 'test_receipt_acceptance_semantics.py'),
    ('surface2-symlink-escape-allowed', 'test_evidence_allowlist.py'),
    ('surface4-stale-fallback-first-item', 'test_evidence_allowlist.py'),
]


def main():
    results = {'reference_app_sha256': packet_app_sha256(), 'baseline_runs': [],
               'mutation_runs': []}
    failed = []
    for module in MODULES:
        r = run_module(module)
        results['baseline_runs'].append(r)
        if r['exit'] != 0:
            failed.append(r)
    for mutant, module in MUTANTS:
        ident = make_mutant(mutant, HERE / '.mutant_sandbox' / ('app_%s.py' % mutant))
        r = run_module(module, source=ident)
        r['mutant'] = mutant
        r['expected'] = 'designated module must FAIL against this deliberately broken copy'
        r['caught_mutation'] = (r['exit'] != 0)
        results['mutation_runs'].append(r)
        if not r['caught_mutation']:
            failed.append(r)
    out = HERE.parent / 'TEST_RESULTS.json'
    out.write_text(json.dumps(results, indent=2))
    if failed:
        print('FAILURES: %d' % len(failed))
        for f in failed:
            print(f.get('mutant', f['module']), 'exit', f['exit'])
            print(f['tail'][-800:])
        return 1
    print('ALL baseline checks passed; every designated mutant was caught.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
