# publication_plan.md — Sign-Off series (plans only; nothing published)

- Original title / logline: Sign-Off — "One night operator. Three hundred signed
  ships. All signed eleven seconds too early."
- Buyer/audience/channel: microdrama-vertical platforms and procedural-drama channels;
  pitch format: 120 s landscape episode (16:9 1280x720) + vertical recut.
- Packaging variants: (1) standalone episode page with embedded captions; (2)
  two-part split at the audit-log reveal; (3) series pilot + trailer cut.
- Sample sponsor/service offer: a procedural-observability brand tied to the sign-off
  theme (e.g. SaaS audit-company intro card), price illustrative $250/episode
  integration, never promised here.
- Per-episode budget (modeled): authoring labor 4 h ($480 at $120/h internal rate),
  compute $0 (local ffmpeg), rights $0 (original/eSpeak GPL).
- Monetization scenarios (modeled only; measured audience/revenue = 0):
  low 0 views: $0; base 20k views, $0.5-2 RPM-equivalent sponsorship ≈ $10-40;
  high 200k views + one sponsor slot ≈ $250-450. Break-even method: episodes until
  cumulative modeled sponsorship + reduced per-episode labor cost exceeds host and
  authoring time — all hypothetical.
- Platform synthetic-media disclosure and eligibility checklist per platform: TODO,
  not a promise. No monetization enabled, nothing uploaded, no audience contacted.
