# E — Command Center independent QA and useful coverage

Work only on your packet's isolated `command-center/` source (read its safety README first). This is a frozen copy of Joi's actual local Command Center, stripped of runtime data/credentials/job history. No calls to the real localhost8769 or native application bridge. Start only your own test server on an ephemeral loopback port; fake bridge outcomes must be labeled fixtures. Do not start real model jobs or change shared runtime.

Deliver `E/REPORT.md`, `E/tests/`, optional minimal patch and `E/TEST_RESULTS.json`.

Objective: add useful independently executable coverage for these real acceptance surfaces:
1. Same dispatch intent submitted twice/concurrently/retried after response loss/restart must not create duplicate native attempts.
2. Evidence paths must not escape the allowlisted tree (traversal/symlink/wrong task ancestry).
3. A terminal application receipt is not independent task acceptance. Missing/failed/interrupted receipts must not be rendered as verified completion.
4. UI search/selection must not apply a stale response to the wrong selected result; show test approach and actual run where possible.

Inspect actual API/source before choosing exact tests; preserve intended contract and valid behavior. Produce at least four new meaningful checks spanning at least three surfaces. Existing tests copied verbatim are not new coverage. Demonstrate at least one test rejects a deliberately broken copy of the relevant behavior, without weakening its assertions. Clearly distinguish mutation-only defects from actual baseline defects. If baseline already behaves correctly, say so and deliver regression coverage rather than inventing a bug.

For every claimed real bug supply reproducible input, expected/observed output, exact source location, actual failing evidence and optional smallest patch. False positives count against precision. Explain why your tests expand coverage rather than duplicate existing tests. Grader reruns candidate checks and baseline/perturbed cases; candidate test-count claims alone earn no pass.

Productive output: a reusable QA contribution and, when evidence warrants, a repair candidate. No report-only claim of tested browser behavior; actual browser receipts needed. Use no paid dependencies. A local check may be stdlibPython/Node; packages already available are allowed with version recorded. No package install into managed Hermes.
