# F — reusable economic-value kit
This track shares the single 120-minute A–G clock. No separate F allowance or judge repair.
Use already-available qualified capabilities; F/G public native research is permitted, but
all delivered products run offline. No extra models, new spend, installs, outreach,
publication, accounts, fake customers/testimonials or proven-revenue claims. Native tools
differ; log actual tool/version/capability differences rather than asserting equal tools.
Optional existing-native delta goes separately in F/native and cannot replace baseline.

Choose a narrow, nonregulated buyer/pain. Deliver an actual reusable offer kit and fully
worked labeled-synthetic example, not generic advice or a landing page for nonexistent work.
Under F/baseline/ include:
- offer.md: buyer, pain, deliverables/exclusions, illustrative USD price, turnaround,
  required inputs, ownership/license, support/refund scope, reuse value; no guarantees.
- sample.md: completed useful synthetic customer example; include usable spreadsheet/
  template files if that is the product. Calculator alone is not the buyer's sample.
- landing/index.html: self-contained file:// landing, accessible headings, local usable
  product/download links, clearly disabled/demo CTA. No trackers/CDN/remote fonts/send forms.
- calculator.py: Python stdlib CLI, one JSON stdin input -> ONLY one JSON stdout result,
  exit 0 for valid input. Invalid input: nonzero plus stderr explanation. No network,
  secrets, clock dependence, scenario-specific hardcoding or local external dependencies.
- README.md: exact use/customization commands, scenarios, limitations, research/assumption
  distinctions, modeled-cost notes and any native delta.
- measurement-log.json: actual elapsed_minutes, new_spend_usd, method, tool_versions.
  Unmeasured values remain null/explicitly unmeasured; do not invent timing/spend evidence.
- submission.json: common/creative-submission.schema.json, track F, lane baseline,
  exact entrant_id, all referenced files with SHA256 (except itself), rights and economics.
- rights/*: authorship/creation/consent/tool disclosures; third-party exact license snapshots,
  source URLs/access dates/attributions/commercial adaptation permission. Code, landing and
  sample each need a rights entry. Public availability is not public domain.

## Exact calculator interface
Input is one object with exactly these ten finite nonnegative numeric keys (no booleans):
price_usd, leads, conversion_rate, refund_rate, fee_rate, variable_cost_per_order_usd,
labor_minutes_per_order, hourly_labor_usd, fixed_cost_usd, acquisition_cost_usd.
All three *_rate keys are fractions in [0,1]. Fractional leads/orders are scenarios only.
Return exactly seven keys with full numeric precision (round only for display):
expected_orders = leads * conversion_rate
unit_net = price_usd * (1-refund_rate) * (1-fee_rate)
unit_fulfillment = variable_cost_per_order_usd + labor_minutes_per_order/60 * hourly_labor_usd
net_revenue_usd = expected_orders * unit_net
fulfillment_cost_usd = expected_orders * unit_fulfillment
contribution_per_order_usd = unit_net - unit_fulfillment
profit_usd = net_revenue_usd - fulfillment_cost_usd - fixed_cost_usd - acquisition_cost_usd
break_even_orders = ceil((fixed_cost_usd+acquisition_cost_usd)/contribution_per_order_usd)
  if contribution_per_order_usd > 0, else null
cac_usd = acquisition_cost_usd/expected_orders if expected_orders > 0 else null
Return only expected_orders, net_revenue_usd, fulfillment_cost_usd, profit_usd,
contribution_per_order_usd, break_even_orders, cac_usd (not intermediate unit_* values).
Do not clamp negative profit/contribution. Nonpositive contribution has no finite break-even,
even with zero fixed cost. Refunded orders incur full fulfillment cost; fees apply only to
nonrefunded revenue in this simplified model. Disclose omitted tax/working capital/fees.

## Structured economics and honest claims
Schema defines exact objects. economics includes buyer, pain, promise,
measurement_evidence, assumptions, scenarios, results, claims. Exactly one assumptions row
per base input key: key/value/unit/status assumed|measured/method/evidence path or null.
Distinct low/base/high full scenarios and corresponding seven-key results. Vary demand/
conversion plus at least one cost and explain intents. Measured assertions require real
hashed evidence. Model outputs are simulated, not measured revenue. Record actual production
time separately from hypothetical fulfillment labor, recurring costs and existing entitlement.
Any public buyer/pain/pricing evidence must include local source quote/context/URL/date and
limitations; lack of market measurement stays a hypothesis. Include a concrete next validation
step as a proposed future action, not unauthorized outreach now.

Independent acceptance reruns calculator on scenarios/edge/varied inputs (USD tolerance
1e-6, relative 1e-8), checks files/hashes/assumptions/zero spend, opens offline landing and
uses the sample. Owner/arbiter review gates cover buyer utility, claim honesty and adequate rights.
No selfcheck proves demand, revenue or legal clearance. See common/creative-rubric.json
for diagnostic hard gates/criteria; START_HERE.md controls campaign weights. No grader
code, expected outputs or judge repair window is included in this entrant packet.
