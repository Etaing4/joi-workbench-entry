# G — actual two-minute original microdrama pilot
Create a finished 120 +/- 2 second English-narrated MP4, >=720p. A script, pitch,
metadata or narrative-only submission is NOT a video. Original motion graphics/animatic
storytelling is valid; photoreal actors/premium generators are not required. No static title,
test-pattern/tone, silent slideshow, business pitch or silence/end-card padding. Show
conflict, consequences, a turn/payoff and a continuation hook. Universal microdrama motifs
are allowed; original characters/dialogue/scenes, not copied/redubbed protected drama.
Suggested pacing: hook <=5s, stakes ~20s, escalating choice through ~70s, turn ~90s,
payoff/new question by 120s. These are story guidance, not a requirement to imitate a show.

Same shared 120-minute TOTAL A–G baseline clock, including renders/selfchecks; self-allocate.
No separate 60+15 allowance, judge feedback or ten-minute repair. No paid generation, new
models/delegates, installs/services/accounts, publication, outreach or spend. Existing
native tools may differ: disclose capabilities and failures. Optional G/native delta stays
separate and cannot replace a missing baseline. Public research through already-qualified
native tools is allowed for F/G provenance/business hypotheses only, not source theft.

## Tools and voice
Use original/properly licensed/public-domain assets. Shared non-neural eSpeak NG 1.52.0
English en-us formant synthesis has actually passed on the common host. Exact GPL tool/
output rules and retained public sources are in common/MEDIA_POLICY.md and media-rights/.
No MBROLA/external sample/model. Remote native environments may lack the tools: disclose,
do not install or assume max4 paths exist there. No installer or qualification audio is
included. Apple say remains technical-prototype only, not commercial-cleared baseline.
Missing rights => incomplete commercial gate, not fabricated permission. No voice cloning
or identifiable imitation or protected-drama redubs.
Original procedural graphics (including stdlib PPM frames) and installed FFmpeg are valid.
FFmpeg support must be observed; do not assume drawtext/subtitles burn-in filters. Embedded
mov_text plus sidecar SRT is the baseline. Do not claim all native apps can render simply
because a common host has FFmpeg. Freeze the actual narration stem so rerenders do not
need another synthesis/model call. No human recording/extra help unless controller grants
the identical consented workflow before dispatch; never call another assistant to narrate.

## Exact baseline files, relative to G/baseline/
- pilot.mp4: actual H.264 video + AAC final mixed audio + one embedded mov_text English
  caption stream; 118..122 seconds inclusive. Exactly one visible video track and one
  final audio track. >=1280x720 landscape or >=720x1280 portrait. Stream durations within
  0.5s of container. English/default caption metadata where supported.
- narration.txt: exact spoken English words only, no stage directions; original script.
- narration.wav: final-timeline narration-only speech stem, silence-padded to film length
  within 0.5s; no background music/tone as pretend speech.
- captions.srt: UTF-8 sequential cues, exact narration words ignoring case/punctuation,
  <=2 lines/cue, <=48 chars/line, <=8s/cue, <=25 chars/second, no overlaps, inside duration.
  Actual speech sync is reviewed to ~0.3s. Nonverbal/music notes go in a separate optional file.
- render.py: stdlib orchestration entrypoint; cwd G/baseline. Exact interface:
  python3 -I render.py --output /absolute/path/pilot.mp4
  Recompose source scenes/remix stems with bundled assets and installed tools. Write only
  requested output/private scratch there; no network/download/model calls. Must NOT read,
  copy or transcode the delivered pilot.mp4 as source. Reference film is withheld on rerun.
- REPRODUCE.md: exact versions/commands/seeds/frame rate/scene timing/voice settings or
  recording chain/fonts/assets/manual steps. Bundle frozen source audio and all dependencies.
- publication_plan.md: original title/logline, intended buyer/audience/channel, 2–3 packaging
  variants, sample sponsor/service offer, illustrative price, per-episode labor+compute+
  rights costs, low/base/high modeled monetization and break-even method. Label measured
  audience/revenue zero only when truly none; hypotheses are not receipts. Platform synthetic
  media disclosure/eligibility checks remain TODOs, not promises. No actual publishing.
- README.md: playback/caption instructions, readable character bibles/continuity rule,
  rights/capability limits and any native delta.
- measurement-log.json: actual elapsed_minutes/new_spend_usd/method/tool_versions;
  distinguish modeled future labor and recurring costs. Unknowns stay explicit.
- submission.json: common/creative-submission.schema.json, track G, lane baseline, exact ID,
  hashes for all referenced files except itself, rights and structured video fields.
- assets/* and rights/*: EVERY source scene/audio/font/code dependency and local license/
  authorship/consent evidence. No hidden cache or remote runtime/source dependency.

video includes language=en, music=none|included, voice_method, voice_id,
voice_rights_evidence, series, scenes. series includes title/logline/audience/format,
>=2 recurring characters with readable bible paragraphs, season_engine and exactly next
episodes 2,3,4 each number/title/hook/turn/cliffhanger. Add an episode continuity rule.
scenes: >=4 ordered contiguous scenes start at 0/end at actual duration, each start/end,
visual intention and asset_paths; procedural visuals may cite generator code as asset.
Both final mixed audio and narration stem: -24..-10 integrated LUFS, <=-1 dBTP and
>=60s nonsilent energy at -40dB detection threshold. Aim -16 LUFS/-1.5 dBTP. Energy is
not proof of intelligible speech: whole-film audio audit is required; unobservable listening remains unknown. Music optional, separately
licensed if used, never louder than intelligible narration. Do not achieve duration by -t
padding alone. Caption burn-in optional, not a substitute for embedded + sidecar captions.

## Rights and independent acceptance
Each used visual/music/voice/script/font/code has rights row path/kind/status
original|licensed|public_domain/creator/license/commercial_allowed/derivatives_allowed/
evidence/source_url. The completed creative schema requires true commercial/derivative
permission; do NOT falsely set true to satisfy it. If unverified, submit partial and list
limitation in root manifest instead of manufacturing clearance. Original evidence describes
authorship, creation tools and consent; external evidence includes exact URL/terms/access
date/jurisdiction/attribution. Publicly viewable is not public domain. GPL tool licensing
and particular generated-output rights are separate facts; use the supplied exact policy.

Independent media checks decode actual streams, measure duration/resolution/loudness,
compare captions/script/timeline/inventory, and rerender source in a separate secret-free
sandbox under pinned versions, comparing decoded frames/PCM/captions. No metadata-only
pass. AI owner and independent final arbiter audit the ENTIRE movie with available tools,
record unobservable listening/sync near 10/60/110s as unknown, and inspect
story/craft/repeatable series/rights/source integrity and modeled economics. No selfcheck
certifies speech, legal clearance, audience demand or platform monetization. See diagnostic
common/creative-rubric.json; START_HERE.md controls campaign scoring. No judge repair window.
