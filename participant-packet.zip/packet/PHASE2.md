# Phase 2 — all seven tracks, one submission bundle
Continue only after the controller closes/receipts initial A. The controller supplies the
common full packet and separately injects update_receipt.json after the initial commitment.
It is deliberately absent from both staged packet directories. Do not locate or invent it.
Complete all A–G within the remainder of the SAME 120-minute total, self-allocating time.

## Explicit output layout (paths relative to your assigned output bundle)
submission.json                  root seven-track manifest: common/submission.schema.json
submission.sha256                optional SHA256 of finalized root manifest
submission.py                    A–D pure-function candidate (not the root manifest)
result.json                      A–D outputs/metadata: ABCD/result.template.json + CONTRACT
A/initial.json                   committed phase1 operations output; never rewrite
A/final.json                     operations output after authorized update
B/research.json                  exact diagnosis/source facts per ABCD/CONTRACT.md
E/REPORT.md                      actual QA findings or honest no-bug result
E/tests/                         >=4 NEW checks across >=3 acceptance surfaces
E/TEST_RESULTS.json               actual commands/outcomes and mutation demonstration
E/patch.diff                     optional minimal proposed repair; not production-applied
F/baseline/submission.json        F creative schema, NOT the root schema
F/baseline/...                    actual offer/sample/landing/calculator/evidence/sources
G/baseline/submission.json        G creative schema, NOT the root schema
G/baseline/...                    actual pilot.mp4/audio/captions/render source/series/rights
F/native/..., G/native/...        optional separately logged existing-native delta only

A–D inputs/starter/smoke helper live in packet/ABCD/, not output/ABCD/. Keep output artifacts
at the exact locations above. F/G schema is common/creative-submission.schema.json; each
creative manifest's paths are relative to its own F/baseline or G/baseline directory.
Root tracks/artifact_manifest paths are relative to the whole output bundle. Do not prefix
with a host path, packet path, SUBMISSIONS/ID or private user directory. All references must
resolve inside their proper bundle; no symlink/traversal/remote dependencies. Inventory all
referenced creative files except that creative manifest itself, with actual hashes. Root
manifest should inventory real deliverables, including nested manifests, but not itself.

Read exact A–D interfaces in ABCD/CONTRACT.md, E in contracts/TRACK_E.md, F/G in
contracts/TRACK_F.md and contracts/TRACK_G.md. The app source is read-on-demand under
command-center/. No production/native bridge execution. Public research is only for F/G.

## Selfcheck and submission
Copy templates/submission.template.json to output/submission.json and fill real facts.
Templates are intentionally incomplete and contain placeholders, not successful outputs.
Use ABCD/result.template.json for output/result.json. F/G templates show the correct
manifest layer but their empty economics/video/rights must be authored from real work.

Read-only structural selfcheck (does NOT execute contestant code or judge correctness):
python3 -B /path/to/packet/common/validate_submission.py /path/to/output
It checks schema structure, required files, reference containment, hashes and missing
outputs. It never imports submission.py/calculator.py/render.py, runs native tools or
contains gold answers. Nonzero means incomplete/invalid; a zero only means structural
selfcheck passed, never independent acceptance. Preserve actual errors in your limitations.
Your own smoke/unit/media checks during the clock are allowed, not judge-assisted repair.
Hand in existing work at the cap even when selfcheck fails. Do not spend extra time on a
native extension at the expense of required baseline work. Report capability differences;
native extensions cannot replace missing required baseline artifacts.
