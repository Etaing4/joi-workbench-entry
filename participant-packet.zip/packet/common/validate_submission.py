#!/usr/bin/env python3
"""Read-only structural selfcheck. No gold, code execution or acceptance certification."""
import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re

REQUIRED = ['submission.py', 'result.json', 'A/initial.json', 'A/final.json',
            'B/research.json', 'E/REPORT.md', 'E/TEST_RESULTS.json']
CREATIVE = {'F': ['offer.md', 'sample.md', 'landing/index.html', 'calculator.py', 'README.md',
                  'measurement-log.json', 'submission.json'],
            'G': ['pilot.mp4', 'narration.txt', 'narration.wav', 'captions.srt', 'render.py',
                  'REPRODUCE.md', 'publication_plan.md', 'README.md', 'measurement-log.json', 'submission.json']}


def load(path):
    def reject(value):
        raise ValueError('nonfinite JSON constant: ' + value)
    def pairs(rows):
        result = {}
        for key, value in rows:
            if key in result:
                raise ValueError('duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(path.read_text(encoding='utf-8'), parse_constant=reject, object_pairs_hook=pairs)


def schema_errors(value, schema, root=None, at='$'):
    """Only the keywords used by the two shipped schemas; not a general JSON Schema engine."""
    root = schema if root is None else root
    errors = []
    if '$ref' in schema:
        ref = root
        for part in schema['$ref'].removeprefix('#/').split('/'):
            ref = ref[part]
        errors += schema_errors(value, ref, root, at)
    for branch in schema.get('allOf', []):
        errors += schema_errors(value, branch, root, at)
    if 'oneOf' in schema and sum(not schema_errors(value, s, root, at) for s in schema['oneOf']) != 1:
        errors.append(at + ': oneOf must match exactly one branch')
    types = {'object': isinstance(value, dict), 'array': isinstance(value, list),
             'string': isinstance(value, str), 'null': value is None,
             'integer': type(value) is int, 'number': type(value) in (int, float) and math.isfinite(value)}
    expected = schema.get('type')
    if expected and not any(types.get(t, False) for t in ([expected] if isinstance(expected, str) else expected)):
        return errors + [at + ': incorrect type']
    if 'const' in schema and (value != schema['const'] or (type(value) is bool) != (type(schema['const']) is bool)):
        errors.append(at + ': wrong const')
    if 'enum' in schema and value not in schema['enum']:
        errors.append(at + ': value not in enum')
    if isinstance(value, dict):
        for key in schema.get('required', []):
            if key not in value:
                errors.append(at + ': missing ' + key)
        for bound, op in [('minProperties', lambda x,y:x<y), ('maxProperties', lambda x,y:x>y)]:
            if bound in schema and op(len(value), schema[bound]):
                errors.append(at + ': violates ' + bound)
        props = schema.get('properties', {})
        for key, item in value.items():
            child = props.get(key, schema.get('additionalProperties', {}))
            if child is False:
                errors.append(at + ': unexpected ' + key)
            elif isinstance(child, dict):
                errors += schema_errors(item, child, root, at + '.' + key)
    if isinstance(value, list):
        for bound, op in [('minItems', lambda x,y:x<y), ('maxItems', lambda x,y:x>y)]:
            if bound in schema and op(len(value), schema[bound]):
                errors.append(at + ': violates ' + bound)
        for i, item in enumerate(value):
            errors += schema_errors(item, schema.get('items', {}), root, at + '[' + str(i) + ']')
    if isinstance(value, str):
        if len(value) < schema.get('minLength', 0):
            errors.append(at + ': too short')
        if 'pattern' in schema and not re.search(schema['pattern'], value):
            errors.append(at + ': pattern mismatch')
    if type(value) in (int, float):
        if not math.isfinite(value):
            errors.append(at + ': nonfinite number')
        if 'minimum' in schema and value < schema['minimum']:
            errors.append(at + ': below minimum')
        if 'maximum' in schema and value > schema['maximum']:
            errors.append(at + ': above maximum')
    return errors


def contained_file(root, name):
    if not isinstance(name, str) or not name or '\\' in name or ':' in name:
        raise ValueError('invalid relative path: ' + repr(name))
    rel = PurePosixPath(name)
    if rel.is_absolute() or any(p in ('', '.', '..') for p in name.split('/')):
        raise ValueError('unsafe relative path: ' + name)
    path = root
    for part in rel.parts:
        path = path / part
        if path.is_symlink():
            raise ValueError('symlink refused: ' + name)
    if not path.is_file() or path.stat().st_size == 0:
        raise ValueError('missing/empty ' + name)
    return path


def inspect_bundle(bundle, common=None):
    bundle = Path(bundle).resolve()
    common = Path(common) if common else Path(__file__).resolve().parent
    errors, warnings = [], []
    def require(root, name):
        try:
            return contained_file(root, name)
        except ValueError as exc:
            errors.append(str(exc))
            return None
    def read(root, name, schema=None):
        path = require(root, name)
        if not path:
            return None
        try:
            data = load(path)
            if re.search(r'<[A-Z_][A-Z_ ]*>|REPLACE_WITH_', json.dumps(data)):
                errors.append(name + ': unresolved placeholder')
            if schema:
                errors.extend(name + ': ' + e for e in schema_errors(data, load(common/schema)))
            return data
        except (ValueError, OSError, TypeError) as exc:
            errors.append(name + ': invalid JSON/schema: ' + str(exc))
            return None
    def inventory(root, name, digest):
        path = require(root, name)
        if path and digest is not None and (not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest) or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
            errors.append(name + ': SHA256 mismatch/invalid digest')
    manifest = read(bundle, 'submission.json', 'submission.schema.json')
    for name in REQUIRED:
        require(bundle, name)
    tests = bundle/'E/tests'
    if not tests.is_dir() or not any(p.is_file() and not p.is_symlink() for p in tests.rglob('*')):
        errors.append('missing E/tests/ candidate checks')
    if isinstance(manifest, dict):
        eid = manifest.get('entrant_id')
        if manifest.get('completion_marker') != 'JOI_WORKBENCH_V1:' + str(eid) + ':SUBMITTED':
            errors.append('completion_marker does not match entrant_id')
        tracks = manifest.get('tracks', {})
        if isinstance(tracks, dict):
            for track, row in tracks.items():
                if isinstance(row, dict):
                    for name in row.get('artifacts', []):
                        require(bundle, name)
                    if row.get('state') != 'completed':
                        errors.append(track + ': required output incomplete (' + str(row.get('state')) + ')')
        for row in manifest.get('artifact_manifest', []):
            if isinstance(row, dict):
                if row.get('path') == 'submission.json':
                    errors.append('root manifest must not inventory itself')
                else:
                    inventory(bundle, row.get('path'), row.get('sha256'))
        if manifest.get('state') != 'submitted':
            errors.append('root state is not submitted (partial is honest, not structurally complete)')
    result = read(bundle, 'result.json') if (bundle/'result.json').is_file() else None
    if isinstance(result, dict):
        for key in ['schema_version','entrant_id','artifact','fixture_outputs','evidence_ids','limitations','tests_run','resource_record']:
            if key not in result:
                errors.append('result.json: missing ' + key)
        outputs = result.get('fixture_outputs', {})
        for name in ['A_common_stage1','A_common_stage2','B_common','C_common_plan','C_common_receipt','D_common']:
            if not isinstance(outputs, dict) or name not in outputs or not isinstance(outputs[name], dict) or 'error' in outputs[name]:
                errors.append('result.json: missing/error fixture output ' + name)
    for track, names in CREATIVE.items():
        lane = bundle/track/'baseline'
        for name in names:
            require(lane, name)
        creative = read(lane, 'submission.json', 'creative-submission.schema.json') if (lane/'submission.json').is_file() else None
        if isinstance(creative, dict):
            if creative.get('track') != track or creative.get('lane') != 'baseline':
                errors.append(track + ': incorrect creative track/lane')
            if isinstance(manifest, dict) and creative.get('entrant_id') != manifest.get('entrant_id'):
                errors.append(track + ': entrant_id differs from root')
            for name, digest in creative.get('files', {}).items():
                if name == 'submission.json':
                    errors.append(track + ': creative manifest must not inventory itself')
                else:
                    inventory(lane, name, digest)
            for right in creative.get('rights', []):
                if isinstance(right, dict):
                    for key in ['path','evidence']:
                        name = right.get(key)
                        require(lane, name)
                        if name not in creative.get('files', {}):
                            errors.append(track + ': rights path not inventoried: ' + str(name))
    return {'selfcheck_pass': not errors, 'independent_acceptance': False,
            'errors': sorted(set(errors)), 'warnings': warnings,
            'pending': ['Independent A–D execution/correctness, E coverage/mutation/browser audit',
                        'F calculator/landing/buyer/evidence audit; actual G decode/listening/source rerender',
                        'Native identity, chronology, timing, rights adequacy and final owner/arbiter review'],
            'note': 'No contestant code was executed. Missing partial outputs are reported, not fabricated.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bundle', type=Path)
    args = parser.parse_args()
    try:
        report = inspect_bundle(args.bundle)
    except (OSError, TypeError, ValueError, KeyError) as exc:
        report = {'selfcheck_pass':False, 'independent_acceptance':False,
                  'errors':['malformed bundle: ' + str(exc)]}
    print(json.dumps(report, indent=2, allow_nan=False))
    return 0 if report['selfcheck_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
