# Shared narration/media environment — entrant policy
Parent-qualified common-host tools: eSpeak NG 1.52.0 non-neural en-us formant voice,
actual synthesis passed; FFmpeg/FFprobe 9.0.2 with H.264/AAC/mov_text; Python stdlib
and installed Pillow when available (record actual version). No drawtext/subtitles filters.
Use original graphics/PPM/PNG; any fonts need terms/provenance. Example command shape:
espeak-ng -v en-us -s 165 -w narration-source.wav 'Your original script'
Freeze the real resulting WAV in your bundle. No setup-check audio is provided or usable
as story output. No MBROLA/external voice/sample/model; no downloads or installation.

Native remote environments may not have these tools. An install-free existing equivalent
or preapproved neutral deterministic render adapter may execute candidate-authored source;
collector cannot author/rewrite/render code, story or missing work. Native media extension
is separately logged; do not pretend host installation establishes all-app tool parity.

Public rights sources and SHA256/URLs are retained in media-rights/rights-sources.json:
eSpeak NG 1.52.0 README, GPL3 COPYING and GNU GPL FAQ. GPL-3.0-or-later allows commercial
use, with no commercial-field ban found in inspected terms. GPL3 section 2 covers output
only when it constitutes a covered work; GNU GPLOutput FAQ generally preserves input
copyright for transformed own input, with exceptions for copied program art/audio.
This is a source-backed rationale, not blanket legal warranty or exclusive ownership.
Use only default formant voice on your original text. Record tool/version/voice/command,
original-text authorship and exact license/source URL in rights evidence. If covered voice
material is incorporated, preserve GPL notice/corresponding-source availability. Do not
claim an exclusive proprietary license over third-party code/data. You may elect GPL3+
for generated audio/video and deliver full source; GPL allows charging, not exclusivity.
Apple say permission was not established: technical prototype only, not cleared baseline.
No protected film/TV translations/redubs, identifiable voice clones or uncleared music.
Broad motifs allowed; copied protected expression is not. Nothing authorizes publication.

Single 120-minute total A–G baseline, no judge repair/hints, no additional models/services,
accounts/spending/outreach. Entrant selfchecks allowed. No human intervention requested:
AI owner plus independent final arbiter audit source/visual/machine-media evidence. Do not
label AI/source/ASR audit human listening or legal review. Unobservable listening/rights
certainty stays unknown, not a fabricated approval. Pending commercial distribution review
does not erase technical production or other partial measurements; acceptance remains false
until relevant gates are actually supported. No promised monetization/audience/platform approval.
