# Reusable collection/selfcheck workflow
Commit initial A bytes before the identical controller stimulus. Keep packet inputs
read-only and output relative paths contained. Keep root, A–D and creative manifests
separate. Selfcheck only structure/hashes; independent execution and full-film listening
remain parent work in a secret-free sandbox. Publish unknowns/partials, not invented
success. Record native tool differences; never claim tool parity merely from common
inputs. This procedural note remains in this authorized task rather than modifying skills.
