# Local API v1

Base URL is the server's printed `http://127.0.0.1:PORT`. Only exact `127.0.0.1:PORT` or `localhost:PORT` Host headers are accepted. Use one origin consistently. JSON responses; errors use `{"error":"..."}`. No wildcard CORS, arbitrary file route, provider overrides, URL-opening endpoint, retry or resume API.

## Session and transport

`GET /api/session` sets `joi_session` (HttpOnly, SameSite=Strict) and returns `{"token":"<unpredictable value>"}`. Keep the cookie in a cookie jar and the token in memory. Never put either in a URL or log. Other `/api/*` reads require that cookie. Every POST additionally requires:

```text
Origin: http://127.0.0.1:PORT
Content-Type: application/json
X-Joi-Token: <token>
Cookie: joi_session=<session cookie>
```

POST requires Content-Length, no transfer encoding, and at most 16,384 bytes. Origin must exactly match `http://` plus the Host header. Cross-site Fetch Metadata is rejected. Reload/reinitialize the session after restarting the server; jobs and idempotency keys survive, session tokens do not. Static paths are exactly `/`, `/app.js`, `/style.css`.

## Reads

| Request | Response |
| --- | --- |
| `GET /api/search?q=browser%20agents&kind=all` | `{items, gaps, mode, limit:80, actions}`. `kind` may be `all`, `research`, `task`. Query maximum 500 characters. |
| `GET /api/evidence/<percent-encoded item ID>` | Exact allowlisted research section or task bullet with raw plain text, source, 1-based line, recorded date and source modified time. IDs are returned by search, never filesystem paths. |
| `GET /api/readiness` | `{records, parent_check, dispatch, live_health}`. Dated claims, not continuous live health. |
| `GET /api/jobs` | `{jobs:[...]}` newest 200; reconciles each exact ID's receipt. |
| `GET /api/jobs/joi-<32 hex>` | One reconciled job plus `events:[{at,state,note}]`. |

Search item: `{id, kind, title, raw, source, line, modified_at, recorded_at, status}`. Task items additionally have `execution:"unverified"`. Evidence IDs are line anchors in the currently read source, not immutable document versions. A draft snapshots selected source contents into its persisted prompt; later source edits do not change an existing job's prompt.

## Draft (does not invoke inference)

`POST /api/drafts`

```json
{
  "idempotency_key": "caller-generated-unique-key-at-least-16-chars",
  "payload": {
    "kind": "fixture",
    "objective": "Read fixture.txt and return JOI_FIXTURE_OK: 42."
  }
}
```

The key is 16–100 alphanumeric/underscore/hyphen characters. Generate it once per user intent, retain it across retries/reloads, and send the identical payload again after a lost response. Reusing it with a different JSON payload returns 409; object key order is ignored. Unknown fields are rejected.

Payload fields:

| Field | Allowed values |
| --- | --- |
| `kind` | `fixture`, `review`, `experiment` |
| `objective` | Nonempty text, at most 3,000 characters; untrusted data within fixed read-only scope |
| `url` | Required only for review: exact `https://github.com/owner/repository`; no auth, query, fragment, subpath or local address. Public unauthenticated metadata verification must succeed. |
| `source_ids` | Optional list of up to three current research IDs from the fixed public allowlist; total source text at most 24,000 characters. Task IDs are forbidden. |

Returns HTTP 200 and the job, for both a new draft and an identical retry. The stable `id` is the task ID to show in the dispatch review. Source selection and repository checks run only on new intent creation; identical retries return the persisted draft. Public repository metadata lookup has an eight-second timeout and rejects redirects/unverifiable repositories.

## Explicit submit

`POST /api/jobs/<job.id>/submit` with body `{}`. The UI must first display provider, model, scope, objective, workspace and task ID and obtain an explicit submit action. Returns HTTP 200 and the same job identity. Only a `drafted` job can become `queued`; repeating submission for any later state does not make a new attempt. There is no generic command endpoint. Long jobs run in detached worker subprocesses, independently of the HTTP thread/server lifetime.

Job fields include `id`, `payload`, `provider:"codex"`, `model:"gpt-6-astra"`, `scope:"read-only"`, `workspace`, `prompt`, `state`, `created`, `updated`, `receipt`, `result`, `error`, `operator_completed`, `independently_verified`. Full prompts are visible locally for review; no auth environment is included. `receipt` is the exact parsed canonical bridge receipt, not the worker's exit code. Result text comes only from the bound task's first attempt. Raw logs remain at the exact receipt/workspace paths for owner inspection; they are not a file-serving API.

Lifecycle states: `drafted`, `queued`, `launching`, `running`, `completed`, `failed`, `blocked`, `unknown-interrupted`. There is no inference call implied by `drafted` or `queued`. `completed` means operator completion only. Independent verification is always false in this baseline. `unknown-interrupted` must not trigger automated redispatch; it may later resolve from exact canonical evidence. An HTTP error/lost response is not permission to create a new idempotency key.

Common statuses: 200 success; 400 invalid payload/ID/source; 403 session/origin/host/token rejected; 404 unsupported route; 409 idempotency conflict; 413 body too large; 500 local state failure. Error responses do not include credentials or request bodies.

## Independent acceptance outline

1. Initialize a session and create a fixture draft with a saved unique key. Inspect returned scope and prompt.
2. Explicitly submit its exact ID twice (concurrently if desired). Poll the exact job until terminal; no new key.
3. Independently read the owned `fixture.txt` and check `19 + 23 == 42`; compare the returned result to `JOI_FIXTURE_OK: 42` and inspect native UUID/receipt. App status remains separate from the owner's verification record.
4. Stop/restart only the owned server, initialize its new session, resend the same draft key/payload and submit the original job ID. Assert identical ID, original native UUID, attempt 1, one `launching` event, unchanged canonical attempt count, no new inference.
5. Exercise a server restart while the same job is in flight if a separate owner-approved job is desired. The detached worker should continue; unknown launch without evidence must remain unknown and must not relaunch.

These are owner acceptance steps and were not executed with a real provider during the implementation.
