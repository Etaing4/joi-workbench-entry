// Minimal synthetic DOM unit harness, NOT a browser or screenshot test.
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const {webcrypto}=require('node:crypto');
class Element {
 constructor(tag='div'){this.tagName=tag.toUpperCase();this.children=[];this.attrs={};this.textContent='';this.value='';this.dataset={};this.handlers={};this.classList={toggle(){}};this.open=false;}
 append(...nodes){this.children.push(...nodes);}
 replaceChildren(...nodes){this.children=[...nodes];}
 setAttribute(k,v){this.attrs[k]=v;}
 addEventListener(k,v){this.handlers[k]=v;}
 focus(){this.focused=true;}
 select(){this.selected=true;}
 showModal(){this.open=true;}
 close(){this.open=false;}
 scrollIntoView(){}
}
function setup(){
 const elements=new Map();const storage=new Map();const handlers={};
 const document={querySelector(s){if(!elements.has(s))elements.set(s,new Element(s==='#command'?'input':'div'));return elements.get(s);},querySelectorAll(){return [];},createElement(t){return new Element(t);},createTextNode(t){const n=new Element('#text');n.textContent=t;return n;},addEventListener(k,v){handlers[k]=v;},activeElement:new Element('body')};
 const context=vm.createContext({document,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},crypto:webcrypto,fetch:()=>new Promise(()=>{}),setInterval(){},setTimeout(){},clearTimeout(){},URL,console});
 vm.runInContext(fs.readFileSync('static/app.js','utf8'),context);
 return {context,elements,handlers,document,run:code=>vm.runInContext(code,context)};
}
test('untrusted source text remains literal DOM text',()=>{const h=setup();h.run("state.items=[{id:'r',kind:'research',title:'<script>attack()</script>',raw:'<img src=x onerror=attack()>',source:'synthetic.md',line:1}];renderResults()");const result=h.elements.get('#results').children[1];assert.equal(result.children[0].children[0].textContent,'<script>attack()</script>');assert.equal(result.children[1].textContent,'<img src=x onerror=attack()>');});
test('pending intent survives reload and changes for changed payload',()=>{const h=setup();const a=h.run("pendingIntent({kind:'fixture',objective:'read'})");assert.equal(h.run("pendingIntent({kind:'fixture',objective:'read'})"),a);assert.notEqual(h.run("pendingIntent({kind:'fixture',objective:'changed'})"),a);});
test('group ordering and keyboard selection use the same row order',()=>{const h=setup();h.run("$('#command').value='query';state.items=[{id:'t',kind:'task',title:'Task',raw:'Task',source:'t',line:1},{id:'r',kind:'research',title:'Research',raw:'Research',source:'r',line:1}];renderResults()");assert.equal(h.run('state.visible[0].id'),'r');h.handlers.keydown({key:'ArrowDown',preventDefault(){}});assert.equal(h.run('state.visible[state.selected].id'),'t');});
test('Cmd K focuses command and Escape clears search',()=>{const h=setup();h.handlers.keydown({key:'k',metaKey:true,preventDefault(){}});assert.equal(h.elements.get('#command').focused,true);h.elements.get('#command').blur=()=>{};h.elements.get('#command').value='query';h.handlers.keydown({key:'Escape'});assert.equal(h.elements.get('#command').value,'');});
test('IME and prevented events do not navigate or activate',()=>{for(const extra of [{isComposing:true},{keyCode:229},{defaultPrevented:true}]){const h=setup();h.run("state.visible=[{id:'a'},{id:'b'}];state.selected=0");let prevented=false;h.handlers.keydown({key:'ArrowDown',...extra,preventDefault(){prevented=true;}});assert.equal(h.run('state.selected'),0);assert.equal(prevented,false);}});
test('input immediately disables stale Enter and stale click during debounce',()=>{
 const h=setup();h.run("state.items=[{id:'old',kind:'research',title:'Old',raw:'old',source:'fixture',line:1}];renderResults();globalThis.opened=[];openItem=item=>opened.push(item.id)");
 const oldButton=h.elements.get('#results').children[1];
 h.document.activeElement=h.document.querySelector('#command');
 h.elements.get('#command').value='new query';h.elements.get('#command').oninput();
 h.handlers.keydown({key:'Enter',preventDefault(){}});oldButton.handlers.click();
 assert.equal(h.run('opened.length'),0);assert.equal(h.run('state.visible.length'),0);
 assert.equal(h.elements.get('#results').attrs['aria-busy'],'true');
 assert.match(h.elements.get('#results').children[0].textContent,/Reading|Searching/);
});
test('pending and failed searches cannot activate previous results',async()=>{
 const h=setup();h.run("state.items=[{id:'old',kind:'research',title:'Old',raw:'old',source:'fixture',line:1}];renderResults();globalThis.opened=[];openItem=item=>opened.push(item.id);api=()=>new Promise((resolve,reject)=>{globalThis.rejectSearch=reject})");
 h.document.activeElement=h.document.querySelector('#command');const pending=h.run('search()');
 h.handlers.keydown({key:'Enter',preventDefault(){}});assert.equal(h.run('opened.length'),0);
 h.run("rejectSearch(new Error('Synthetic failure'))");await pending;
 h.handlers.keydown({key:'Enter',preventDefault(){}});assert.equal(h.run('opened.length'),0);
 assert.equal(h.run('state.visible.length'),0);assert.equal(h.elements.get('#results').attrs['aria-busy'],'false');
 assert.equal(h.elements.get('#results').children[0].children[0].textContent,'Search unavailable');
});
test('late responses cannot cross query or view changes',async()=>{
 for(const change of ["$('#command').value='new';$('#command').oninput()", "switchView('tasks')", "$('#command').value='changed without input event'"]){
  const h=setup();h.run("api=()=>new Promise(resolve=>{globalThis.resolveSearch=resolve});globalThis.opened=[];openItem=item=>opened.push(item.id)");
  const pending=h.run('search()');const resolveOld=h.run('resolveSearch');h.run(change);
  resolveOld({items:[{id:'stale',kind:'task',title:'Stale',raw:'old',source:'fixture',line:1}],gaps:[]});await pending;
  h.document.activeElement=h.document.querySelector('#command');h.handlers.keydown({key:'Enter',preventDefault(){}});
  assert.equal(h.run('opened.length'),0,change);assert.equal(h.run('state.visible.length'),0,change);
 }
});
test('latest accepted results remain actionable after an older request fails',async()=>{
 const h=setup();h.run("globalThis.requests=[];api=()=>new Promise((resolve,reject)=>requests.push({resolve,reject}));globalThis.opened=[];openItem=item=>opened.push(item.id)");
 const old=h.run('search()');h.run("$('#command').value='latest';$('#command').oninput()");const latest=h.run('search()');
 h.run("requests[1].resolve({items:[{id:'latest',kind:'research',title:'Latest',raw:'new',source:'fixture',line:1}],gaps:[]})");await latest;
 h.run("requests[0].reject(new Error('Late failure'))");await old;
 h.document.activeElement=h.document.querySelector('#command');h.handlers.keydown({key:'Enter',preventDefault(){}});
 assert.equal(h.run('opened[0]'),'latest');assert.equal(h.run('state.visible.length'),1);
 assert.equal(h.elements.get('#results').attrs['aria-busy'],'false');assert.equal(h.elements.get('#notice').textContent,'');
});
test('unknown Enter never calls a dispatch endpoint',()=>{const h=setup();h.document.activeElement=h.document.querySelector('#command');h.run("$('#command').value='do mysterious things';state.visible=[]");h.handlers.keydown({key:'Enter',preventDefault(){}});assert.match(h.elements.get('#notice').textContent,/Supported actions/);});
