"""HTTP parser/handler integration over in-memory transport; mocked dispatch, no provider calls.
Set JOI_LIVE_HTTP=1 to exercise the same tests over an actual loopback listener.
"""
import concurrent.futures
import http.client
import io
import os
from types import SimpleNamespace
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import app


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=str(app.ROOT))
        self.store = app.Store(Path(self.tmp.name) / 'data')
        self.live = os.environ.get('JOI_LIVE_HTTP') == '1'
        if self.live:
            self.server = app.ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        else:
            self.server = SimpleNamespace(server_port=18769)
        self.server.service = app.Service(self.store)
        self.launch_patch = patch.object(self.server.service, 'launch')
        self.launch = self.launch_patch.start()
        self.catalog_patch = patch('app.catalog', return_value=([{'id':'research:x:1','kind':'research','title':'<script>alert(1)</script>', 'raw':'<img src=x onerror=alert(1)>', 'source':'synthetic.md','line':1,'modified_at':app.now()}], []))
        self.catalog_patch.start()
        if self.live:
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
        self.host = '127.0.0.1:' + str(self.server.server_port)
        status, headers, data = self.request('GET', '/api/session', auth=False)
        self.assertEqual(status, 200)
        self.cookie = headers['Set-Cookie'].split(';')[0]
        self.token = data['token']

    def tearDown(self):
        if self.live:
            self.server.shutdown(); self.server.server_close(); self.thread.join()
        self.launch_patch.stop(); self.catalog_patch.stop(); self.tmp.cleanup()

    def request(self, method, path, body=None, headers=None, auth=True):
        h = {'Host':self.host}
        if auth:
            h.update({'Cookie':self.cookie, 'X-Joi-Token':self.token, 'Origin':'http://' + self.host})
        if body is not None:
            body = json.dumps(body)
            h['Content-Type'] = 'application/json'
        h.update(headers or {})
        if self.live:
            conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
            conn.request(method, path, body=body, headers=h)
            response = conn.getresponse(); raw = response.read(); status = response.status; result_headers = dict(response.getheaders());conn.close()
        else:
            encoded = (body or '').encode()
            h['Content-Length'] = str(len(encoded))
            wire = ('%s %s HTTP/1.1\r\n' % (method,path) + ''.join('%s: %s\r\n' % pair for pair in h.items()) + '\r\n').encode() + encoded
            class MemorySocket:
                def __init__(self, data):
                    self.input=io.BytesIO(data); self.output=io.BytesIO()
                def makefile(self, *args): return self.input
                def sendall(self, data): self.output.write(data)
                def settimeout(self, timeout): pass
            socket=MemorySocket(wire)
            app.Handler(socket,('127.0.0.1',12345),self.server)
            response_socket=MemorySocket(socket.output.getvalue())
            response=http.client.HTTPResponse(response_socket);response.begin()
            raw=response.read();status=response.status;result_headers=dict(response.getheaders())
        data = json.loads(raw) if result_headers.get('Content-Type','').startswith('application/json') else raw.decode()
        return status, result_headers, data

    def draft(self):
        status, _, job = self.request('POST', '/api/drafts', {'idempotency_key':'http-key-1234567890','payload':{'kind':'fixture','objective':'Synthetic HTTP fixture'}})
        self.assertEqual(status, 200)
        return job

    def test_host_and_origin_and_token(self):
        self.assertEqual(self.request('GET','/api/session',headers={'Host':'evil.test'},auth=False)[0],403)
        self.assertEqual(self.request('GET','/api/session',headers={'Sec-Fetch-Site':'cross-site'},auth=False)[0],403)
        self.assertEqual(self.request('GET','/api/jobs',auth=False)[0],403)
        for headers in [{'Origin':'https://evil.test'}, {'X-Joi-Token':'bad'}, {'Cookie':'joi_session=bad'}]:
            self.assertEqual(self.request('POST','/api/drafts',{},headers=headers)[0],403)
        self.assertEqual(self.request('POST','/api/drafts',{},headers={'Cookie':self.cookie,'X-Joi-Token':self.token},auth=False)[0],403)

    def test_concurrent_submit_lost_response_keeps_identity(self):
        job=self.draft()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            replies=list(pool.map(lambda _:self.request('POST','/api/jobs/'+job['id']+'/submit',{}), range(12)))
        self.assertTrue(all(r[0]==200 and r[2]['id']==job['id'] for r in replies))
        self.assertEqual(len(self.store.jobs()),1)
        self.assertEqual(sum(e['state']=='queued' for e in self.store.events(job['id'])),1)
        self.assertEqual(self.draft()['id'],job['id'])

    def test_conflict_body_limits_and_overrides(self):
        self.draft()
        self.assertEqual(self.request('POST','/api/drafts',{'idempotency_key':'http-key-1234567890','payload':{'kind':'fixture','objective':'different'}})[0],409)
        self.assertEqual(self.request('POST','/api/drafts',{'large':'x'*17000})[0],413)
        self.assertEqual(self.request('POST','/api/drafts',{'idempotency_key':'another-key-123456789','payload':{'kind':'fixture','objective':'x','provider':'claude'}})[0],400)

    def test_traversal_explicit_assets_and_evidence(self):
        for path in ['/../app.py','/data/jobs.sqlite3','/static/../app.py','/%2e%2e/app.py','/api/evidence/../../secret','/api/jobs/../x']:
            self.assertIn(self.request('GET',path)[0],(400,404))
        self.assertEqual(self.request('GET','/api/evidence/research%3Ax%3A1')[0],200)

    def test_xss_plain_text_and_browser_policy(self):
        status,headers,html=self.request('GET','/')
        self.assertEqual(status,200)
        self.assertIn("script-src 'self'",headers['Content-Security-Policy'])
        self.assertIn("frame-ancestors 'none'",headers['Content-Security-Policy'])
        self.assertNotIn('Access-Control-Allow-Origin',headers)
        _,_,items=self.request('GET','/api/search?q=script')
        self.assertEqual(items['items'][0]['raw'],'<img src=x onerror=alert(1)>')
        _,_,js=self.request('GET','/app.js')
        self.assertNotIn('innerHTML',js)
        self.assertNotIn('insertAdjacentHTML',js)
        self.assertIn('textContent',js)


if __name__=='__main__': unittest.main()
