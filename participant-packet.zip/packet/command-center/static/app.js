'use strict';
const $ = s => document.querySelector(s);
const state = {view:'research', items:[], jobs:[], selected:0, token:'', source:null, seq:0, currentJob:null};
function el(tag, text, cls) { const node=document.createElement(tag); if(text!==undefined) node.textContent=text; if(cls) node.className=cls; return node; }
function clear(node) { node.replaceChildren(); }
function notice(text='') { $('#notice').textContent=text; }
function date(value) { const d=new Date(value); return Number.isNaN(+d) ? value : d.toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}); }
async function api(path, body) {
 const response=await fetch(path, {method:body===undefined?'GET':'POST', credentials:'same-origin', headers:body===undefined?{}:{'Content-Type':'application/json','X-Joi-Token':state.token}, body:body===undefined?undefined:JSON.stringify(body)});
 const data=await response.json(); if(!response.ok) throw new Error(data.error || 'Local request failed'); return data;
}
function tag(text) { return el('span',text,'tag'+(/unknown|blocked|drafted/.test(text)?' warn':/failed/.test(text)?' bad':'')); }
function empty(node,title,text) { const box=el('div',undefined,'empty'); box.append(el('strong',title),el('span',text)); node.append(box); }
function openDrawer(title,kicker='EVIDENCE') { state.currentJob=null; $('#drawer-title').textContent=title; $('#drawer-kicker').textContent=kicker; clear($('#drawer-body')); if(!$('#drawer').open) $('#drawer').showModal(); }
function closeDrawer() { $('#drawer').close(); state.currentJob=null; $('#command').focus(); }
function searchSignature() { return JSON.stringify([state.view,$('#command').value]); }
function invalidateSearch() {
 ++state.seq;state.items=[];state.visible=[];state.selected=0;state.visibleSignature=null;
 const box=$('#results');clear(box);box.setAttribute('aria-busy','true');box.setAttribute('aria-activedescendant','');
 $('#result-count').textContent='Searching…';box.append(el('div','Reading allowlisted sources…','loading'));
}
function switchView(view) {
 state.view=view; document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 const titles={research:['RESEARCH → POSSIBILITY','A little clarity.\nA useful next move.','Find what you know. Decide what comes next.','Research library'],tasks:['CONTEXT → DECISION','The work,\nin perspective.','Recorded task summaries. Execution evidence stays separate.','Canonical task summaries'],jobs:['INTENT → EVIDENCE','Every job.\nA clear receipt.','Durable intents, bounded execution, inspectable outcomes.','Job history']};
 const t=titles[view]; $('#section-kicker').textContent=t[0]; clear($('#view-title')); const parts=t[1].split('\n'); $('#view-title').append(document.createTextNode(parts[0]),el('br'),document.createTextNode(parts[1])); $('#view-description').textContent=t[2]; $('#results-title').textContent=t[3]; search();
}
function renderResults() {
 if(state.view!=='jobs'&&state.itemsSignature&&state.itemsSignature!==searchSignature()){invalidateSearch();return;}
 const box=$('#results'); clear(box); let rows;
 if(state.view==='jobs') { const q=$('#command').value.toLowerCase(); rows=state.jobs.filter(j=>!q||(j.payload.objective+' '+j.state+' '+j.id).toLowerCase().includes(q)).map(j=>({id:j.id,kind:'job',title:j.payload.objective,raw:j.error||'Codex · gpt-6-astra · read-only',status:j.state,modified_at:j.updated,job:j})); }
 else rows=state.items.filter(x=>$('#command').value.trim()?true:x.kind===(state.view==='tasks'?'task':'research'));
 const signature=searchSignature(), generation=state.seq;state.visibleSignature=signature;
 state.visible=rows; state.selected=Math.min(state.selected,Math.max(0,rows.length-1)); $('#result-count').textContent=rows.length+' results'+(rows.length===80?' · capped at 80':'');
 if(!rows.length) { empty(box,'No matching results',state.view==='jobs'?'Draft an acceptance fixture or a bounded job to get started.':'Try fewer keywords, inspect Tasks, or draft a supported job. Unknown requests never execute automatically.'); return; }
 const groups=[['research','Public research'],['task','Recorded tasks'],['job','Dispatch history']];
 const ordered=groups.flatMap(([kind])=>rows.filter(x=>x.kind===kind)); state.visible=ordered;
 for(const [kind,label] of groups) { const group=ordered.filter(x=>x.kind===kind); if(!group.length)continue; box.append(el('div',label,'group-label')); for(const item of group) {
  const index=ordered.indexOf(item); const button=el('button',undefined,'result'+(index===state.selected?' selected':'')); button.id='result-'+index; button.setAttribute('role','option');button.setAttribute('aria-selected',String(index===state.selected));button.tabIndex=-1;
  const top=el('div',undefined,'result-top');top.append(el('span',item.title,'result-title'),el('span','↗','result-arrow'));
  const summary=item.raw.replace(/^#+\s.*\n?/,'').replace(/\*\*/g,'');
  const meta=el('div',undefined,'result-meta');meta.append(tag(kind==='job'?item.status:kind==='task'?'Recorded · not live':'Source evidence'),el('span',kind==='job'?date(item.modified_at):item.source+' : '+item.line));
  button.append(top,el('p',summary,'result-summary'),meta);button.addEventListener('click',()=>{if(generation===state.seq&&signature===searchSignature()&&state.visibleSignature===signature)openItem(item);});box.append(button);
 }}
 $('#results').setAttribute('aria-activedescendant','result-'+state.selected);
}
async function search() {
 invalidateSearch();const seq=state.seq, signature=searchSignature();
 const current=()=>seq===state.seq&&signature===searchSignature();
 try { const result=await api('/api/search?q='+encodeURIComponent($('#command').value)+'&kind='+($('#command').value.trim()?'all':state.view==='tasks'?'task':'research')); if(!current())return; state.items=result.items;state.itemsSignature=signature;state.selected=0; renderResults(); notice(result.gaps.length?'Some allowlisted sources are unavailable: '+result.gaps.map(g=>g.source).join(', '):''); }
 catch(e){if(current()){state.visible=[];state.items=[];state.selected=0;state.visibleSignature=null;notice(e.message);clear($('#results'));$('#result-count').textContent='Search unavailable';empty($('#results'),'Search unavailable','Retry after checking the local server.');}}
 finally{if(current())$('#results').setAttribute('aria-busy','false');}
}
async function openItem(item) {
 if(item.kind==='job')return showJob(item.id);
 openDrawer(item.title,item.kind==='task'?'RECORDED TASK':'SOURCE EVIDENCE'); const body=$('#drawer-body');body.append(el('div','Loading evidence…','loading'));
 try { const data=await api('/api/evidence/'+encodeURIComponent(item.id)); if($('#drawer-title').textContent!==item.title)return;clear(body);
 body.append(el('div',data.source+':'+data.line+'\nSource file modified: '+date(data.modified_at)+(data.recorded_at?'\n'+data.recorded_at:''),'detail-meta'));
 if(data.kind==='task')body.append(el('div','Recorded status only. Historical and conflicting bullets are preserved independently. Active execution is unverified.','scope-box'));
 body.append(el('pre',data.raw));
 const urls=[...new Set(data.raw.match(/https:\/\/[^\s<>\])"`]+/g)||[])].slice(0,30);
 if(urls.length){const links=el('details',undefined,'source-links');links.append(el('summary','Public links in this evidence'));for(const url of urls){try{const parsed=new URL(url);if(parsed.username||parsed.password)continue;const a=el('a',url);a.href=parsed.href;a.target='_blank';a.rel='noopener noreferrer';links.append(a);}catch(_){}}body.append(links);}
 if(data.kind==='research'){const draft=el('button','Draft an experiment from this evidence →','secondary');draft.onclick=()=>draftJob('experiment',data);body.append(draft);}
 }catch(e){clear(body);body.append(el('p',e.message,'error-inline'));}
}
async function refreshJobs(){
 try{const data=await api('/api/jobs');state.jobs=data.jobs; const node=$('#recent-jobs');clear(node);if(!data.jobs.length)empty(node,'A clean slate','No jobs dispatched. Start with a small, inspectable result.');
 for(const job of data.jobs.slice(0,4)){const b=el('button',undefined,'recent');b.append(el('span',job.payload.objective,'recent-title'),tag(job.state),el('small',date(job.updated)));b.onclick=()=>showJob(job.id);node.append(b);}if(state.view==='jobs')renderResults();}
 catch(e){notice(e.message);}
}
function pendingIntent(payload){
 const fingerprint=JSON.stringify(payload);let pending;
 try{pending=JSON.parse(localStorage.getItem('joi.pendingDraft')||'null');}catch(_){pending=null;}
 if(!pending||pending.fingerprint!==fingerprint){pending={fingerprint,key:crypto.randomUUID()};localStorage.setItem('joi.pendingDraft',JSON.stringify(pending));}return pending.key;
}
function draftJob(kind='fixture',source=null,objective='') {
 openDrawer('Make the next move bounded.','NEW JOB');state.source=source;const body=$('#drawer-body');body.append($('#draft-template').content.cloneNode(true)); const form=$('#draft-form'); form.elements.kind.value=kind;
 const defaults={fixture:'Read the owned fixture, sum its two numbers, and return JOI_FIXTURE_OK: 42.',review:'Review the public repository for architecture, limitations and one useful bounded experiment. Cite source evidence.',experiment:'Turn this idea into a small, read-only experiment plan with clear acceptance criteria and unresolved questions.'};
 form.elements.objective.value=objective||defaults[kind];
 const sync=()=>{$('#repo-label').hidden=form.elements.kind.value!=='review';form.elements.url.required=form.elements.kind.value==='review';};sync();form.elements.kind.onchange=()=>{form.elements.objective.value=defaults[form.elements.kind.value];sync();};
 if(source){const label=el('label',undefined,'check');const input=el('input');input.type='checkbox';input.name='includeSource';input.checked=true;label.append(input,document.createTextNode('Include public evidence: '+source.title));$('#draft-source').append(label);}
 form.onsubmit=async event=>{event.preventDefault();const submit=form.querySelector('button[type=submit]');submit.disabled=true;form.querySelector('.error-inline')?.remove();
  try{const payload={kind:form.elements.kind.value,objective:form.elements.objective.value};if(payload.kind==='review')payload.url=form.elements.url.value;if(source&&form.elements.includeSource.checked)payload.source_ids=[source.id];const job=await api('/api/drafts',{idempotency_key:pendingIntent(payload),payload});await refreshJobs();await showJob(job.id);}
  catch(e){form.append(el('p',e.message,'error-inline'));submit.disabled=false;}
 };
}
async function showJob(id){
 openDrawer('Job details','DURABLE JOB');state.currentJob=id;const body=$('#drawer-body');body.append(el('div','Reading receipt…','loading'));
 try{const job=await api('/api/jobs/'+id);if(state.currentJob!==id)return;clear(body);$('#drawer-title').textContent=job.payload.objective;
 body.append(el('div',job.id+'\nCodex · '+job.model+' · '+job.scope+'\nCreated '+date(job.created)+' · Updated '+date(job.updated),'detail-meta'));
 const verification=el('div',undefined,'verification');verification.append(tag(job.state),tag(job.operator_completed?'Operator completed':'Operator completion unconfirmed'),tag('Independent verification: not performed'));body.append(verification);
 const scope=el('div',undefined,'scope-box');scope.append(el('strong','Scope & dispatch review'),el('p','Kind: '+job.payload.kind+' · 180 seconds maximum'),el('p','Workspace: '+job.workspace));if(job.payload.url)scope.append(el('p','Public repository: '+job.payload.url));scope.append(el('p','The native CLI owns authentication. Read-only is a write restriction, not a private-file read sandbox.'));body.append(scope);
 if(job.error)body.append(el('p',job.error,'error-inline'));
 const actions=el('div',undefined,'detail-actions');
 if(job.state==='drafted'){const button=el('button','Dispatch to Codex →','primary');button.onclick=async()=>{button.disabled=true;try{await api('/api/jobs/'+id+'/submit',{});localStorage.removeItem('joi.pendingDraft');await refreshJobs();await showJob(id);}catch(e){body.append(el('p',e.message+' Retry uses the same task ID.','error-inline'));button.disabled=false;}};actions.append(button);}
 const refresh=el('button','Refresh evidence','secondary');refresh.onclick=()=>showJob(id);actions.append(refresh);body.append(actions);
 if(job.result){body.append(el('h2',job.operator_completed?'Operator output':'Partial output · not completion'),el('pre',job.result));}
 const prompt=el('details');prompt.append(el('summary','Inspect exact persisted prompt'),el('pre',job.prompt));body.append(prompt);
 if(job.receipt){const receipt=el('details');receipt.append(el('summary','Canonical bridge receipt'),el('pre',JSON.stringify(job.receipt,null,2)));body.append(receipt);}
 const events=el('details');events.open=true;events.append(el('summary','Intent & evidence timeline'));for(const event of job.events){const row=el('div',undefined,'event');row.append(el('strong',event.state+' · '+date(event.at)),el('div',event.note));events.append(row);}body.append(events);
 }catch(e){clear(body);body.append(el('p',e.message,'error-inline'));}
}
async function showReadiness(){openDrawer('Readiness is dated evidence.','APPLICATIONS');const body=$('#drawer-body');try{const data=await api('/api/readiness');body.append(el('div','Live health: unverified. Dispatch is available only through Codex. These records do not establish that any application is currently authenticated or serving.','scope-box'));body.append(el('p','Parent check: '+data.parent_check.checked_at),el('p',data.parent_check.codex),el('p',data.parent_check.claude));for(const item of data.records){body.append(el('h3',item.application),el('div','Last recorded check: '+item.checked_at+' · '+item.health,'detail-meta'),el('p',item.recorded_state));}}catch(e){body.append(el('p',e.message,'error-inline'));}}
$('#close-drawer').onclick=closeDrawer;$('#drawer').addEventListener('click',e=>{if(e.target===$('#drawer')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDrawer();}});
$('#drawer').addEventListener('close',()=>{state.currentJob=null;});
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{ $('#command').value='';switchView(b.dataset.view);});
document.querySelectorAll('[data-query]').forEach(b=>b.onclick=()=>{$('#command').value=b.dataset.query;switchView(b.dataset.query.includes('waiting')?'tasks':'research');$('#command').focus();});
document.querySelectorAll('[data-draft]').forEach(b=>b.onclick=()=>draftJob(b.dataset.draft));
$('#new-job').onclick=()=>draftJob('experiment');$('#fixture').onclick=()=>draftJob();$('#readiness').onclick=showReadiness;$('#refresh-jobs').onclick=refreshJobs;
let debounce;$('#command').oninput=()=>{clearTimeout(debounce);invalidateSearch();debounce=setTimeout(search,160);};
document.addEventListener('keydown',e=>{
 if(e.isComposing||e.keyCode===229||e.defaultPrevented)return;
 if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();if($('#drawer').open)closeDrawer();$('#command').focus();$('#command').select();return;}
 if($('#drawer').open)return;
 if(e.key==='Escape'){$('#command').value='';search();$('#command').blur();return;}
 if(['1','2','3'].includes(e.key)&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)){switchView(['research','tasks','jobs'][Number(e.key)-1]);return;}
 if(e.key==='ArrowDown'||e.key==='ArrowUp'){if(!state.visible?.length)return;e.preventDefault();state.selected=(state.selected+(e.key==='ArrowDown'?1:-1)+state.visible.length)%state.visible.length;renderResults();$('#result-'+state.selected)?.scrollIntoView({block:'nearest'});}
 if(e.key==='Enter'&&(document.activeElement===$('#command')||document.activeElement===$('#results'))){e.preventDefault();const q=$('#command').value.trim();if(/^draft (?:codex )?review\b/i.test(q))return draftJob('review');if(/^(?:turn .* into .*experiment|draft .*experiment)/i.test(q))return draftJob('experiment',null,q);if(state.visibleSignature===searchSignature()&&state.visible?.[state.selected])openItem(state.visible[state.selected]);else notice('Supported actions: keyword search, inspect a result, draft a public repository review, or draft an experiment plan.');}
});
async function init(){try{state.token=(await api('/api/session')).token;await Promise.all([search(),refreshJobs()]);}catch(e){notice('Cannot connect to the local server: '+e.message);}}
init();setInterval(()=>{if(!document.hidden)refreshJobs();},10000);
