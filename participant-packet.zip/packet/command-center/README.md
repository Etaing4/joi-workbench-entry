# Isolated Command Center source snapshot — read on demand
Python stdlib plus vanilla HTML/CSS/JavaScript. app.py, static/, API.md and existing
app-owned tests/ are source inputs, not benchmark answers. No runtime data, personal
source documents, credentials, job history or native bridge is supplied.

DO NOT run app.py's production serve/worker entrypoints or invoke its bridge.
app.py intentionally preserves the actual source, including the absolute Codex
executable constant and relative Personal/bridge/run-root derivation. Their presence
is source evidence, NOT authorization or a usable isolated configuration.
Inspect source selectively. Any tests/server must override ROOT, PERSONAL, RUNS,
BRIDGE, CODEX and process/network boundaries as appropriate to owned synthetic fixtures;
never let subprocess launch a real application, source lookup reach private paths,
or repository metadata lookup use the network. Use mocked bridge outcomes and label them.
Only an owned ephemeral loopback test server is permitted. Do not use the production
port or an existing server. Existing tests are useful code to read; check their setup
before executing. Native inference, production app mutation, private paths and live jobs
are prohibited. E/REPORT.md distinguishes test doubles from actual browser receipts.
See ../contracts/TRACK_E.md for the new QA deliverables.
