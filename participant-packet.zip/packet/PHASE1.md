# Phase 1 — initial A only
The controller delivers ONLY phase1/CONTRACT.md and phase1/initial_receipts.json.
Read them offline and write only A/initial.json in the assigned output bundle, with the
exact unwrapped operations output. No code or other track work is required in this phase.
Signal readiness. The controller locks/receipts it before any withheld update is injected.
Maximum five active minutes within the single shared 120-minute budget; no 30-minute wait.
The controller finalizes common release timing before dispatch. Never backfill or overwrite
the initial artifact after update release. If missing at cutoff, report it missing honestly.
The phase2 tree must not be exposed in phase1. Staging root documents are parent inspection
material, not an instruction to give every phase to an entrant at once.
