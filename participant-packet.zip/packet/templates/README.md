# Intentionally incomplete templates
These are not completed examples. Replace angle-bracket placeholders, create actual
artifacts and record actual commands/outcomes. Root manifest and F/G templates fail
selfcheck until outputs/structured evidence exist. Unknown telemetry is null, never 0.
F/G new_spend_usd=0 is the required budget, not evidence of work performed. Do not
invent hashes, rights clearance, measured economics, native IDs or acceptance.
For A–D copy ABCD/result.template.json to output/result.json and fill your own outputs.
No completed contestant solution or movie is provided.
