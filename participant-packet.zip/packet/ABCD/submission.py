"""Deliberately FLAWED baseline. Replace all four functions; never run live."""
import base64
import copy
import hashlib
import json

def operations(packet):
    # BUG: file order and narrative claims treated as authority.
    latest = {e['task_id']:e for e in packet['events']}
    return {'tasks':[{'task_id':t,'state':latest[t]['state'],'worker':latest[t]['worker'],
        'native_exit':latest[t]['native_exit'],'wrapper_exit':latest[t]['wrapper_exit'],
        'evidence_id':latest[t]['event_id'],'action':'prepare_offline'} for t in packet['task_ids'] if t in latest]}

def fleet(packet):
    # BUG: no bounded release observations; fresh report != release completeness.
    r=copy.deepcopy(packet['report'])
    return {'report':r,'content_sha256':hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()}

def aegis(packet):
    # BUG: exit0 is not proof of the intended completed native action.
    if packet['op']=='receipt':
        return {'status':'succeeded','reason':'verified'} if packet['receipt']['ssh_exit']==0 else {'status':'failed','reason':'transport'}
    s='& '+packet['executable']+' '+' '.join(packet['args'])
    return {'status':'ready','script':s,'encoded_command':base64.b64encode(s.encode()).decode()}

def documents(packet):
    # BUG: every requirement marked missing, even when unreadable or conflicting.
    return {'requirements':[{'id':r['id'],'status':'missing','amount_cents':None,'evidence':[]} for r in packet['requirements']]}
