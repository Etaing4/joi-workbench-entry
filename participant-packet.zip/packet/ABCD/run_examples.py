"""Smoke only: no expected answers and no acceptance claim. Prints JSON."""
import importlib.util
import json
from pathlib import Path
import sys

import argparse

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('submission',type=Path)
    parser.add_argument('--update',type=Path)
    args=parser.parse_args()
    path=args.submission.resolve()
    spec=importlib.util.spec_from_file_location('candidate',path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    fixtures=json.loads((Path(__file__).parent/'fixtures.json').read_text())
    fixtures.update(json.loads((Path(__file__).parent/'initial_receipts.json').read_text()))
    if args.update:
        update=json.loads(args.update.read_text())
        initial=json.loads(json.dumps(fixtures['A_common_stage1']))
        initial['input']['as_of']=update['as_of']
        initial['input']['events'].extend(update['events'])
        fixtures[update['fixture_name']]=initial
    out={}
    for name,f in fixtures.items():
        try:
            out[name]=getattr(mod,f['function'])(f['input'])
        except Exception as exc:
            out[name]={'error':type(exc).__name__+': '+str(exc)}
    print(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False))
